# সাগরের খাতা — Remotion প্রজেক্ট (16:9, 1920×1080, 30fps)

## চালানোর ধাপ
1. `npm install`
2. প্রিভিউ: `npx remotion studio src/index.ts`
3. রেন্ডার: `npx remotion render src/index.ts Story out/story.mp4 --codec=h264 --crf=18`

(প্রথমবার Hind Siliguri ফন্ট ডাউনলোডের জন্য ইন্টারনেট লাগবে।)

## ফাইল
- `public/voice.mp3` — আপনার ভয়েসওভার
- `src/captions.ts` — SRT থেকে নেওয়া ক্যাপশন
- `src/data.ts` — সিন-টাইমলাইন, স্পিচ বাবল, ক্যাপশন লুকানোর সময়
- `src/looks.ts` — ক্যারেক্টারের পোশাক/লুক
- `src/scenesA/B/C.tsx` — সিনের কোড
