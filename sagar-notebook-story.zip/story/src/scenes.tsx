import React from 'react';
import {S1, S2a, S2b, S2c, S2d, S2e, S2f} from './scenesA';
import {S3a, S3b, S3c, S3d, S3e, S4a, S4b, S4c, S4d} from './scenesB';
import {S5a, S5b, S5c, S5d} from './scenesC';
import type {SP} from './props';

export const SCENE_COMPONENTS: Record<string, React.FC<SP>> = {
  s1: S1, s2a: S2a, s2b: S2b, s2c: S2c, s2d: S2d, s2e: S2e, s2f: S2f,
  s3a: S3a, s3b: S3b, s3c: S3c, s3d: S3d, s3e: S3e,
  s4a: S4a, s4b: S4b, s4c: S4c, s4d: S4d,
  s5a: S5a, s5b: S5b, s5c: S5c, s5d: S5d,
};
