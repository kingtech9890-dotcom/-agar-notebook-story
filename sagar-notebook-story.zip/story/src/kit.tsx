import React from 'react';
import {AbsoluteFill, interpolate, spring, useCurrentFrame} from 'remotion';
import {FPS, FONT, OUT, SW, W, H} from './theme';

/* ───────── time helpers ───────── */
export const useT = (t0: number) => {
  const f = useCurrentFrame();
  return {f, T: t0 + f / FPS};
};
export const clamp01 = (v: number) => Math.max(0, Math.min(1, v));
/** 0→1 between local frames a and b */
export const fade = (f: number, a: number, b: number) => interpolate(f, [a, b], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
/** spring pop starting at local frame `at` */
export const pop = (f: number, at: number, damping = 11) =>
  f < at ? 0 : spring({frame: f - at, fps: FPS, config: {damping, stiffness: 150, mass: 0.7}});
/** convert a scene-relative second to a local frame */
export const sec = (s: number) => Math.round(s * FPS);

/** Pop-in group: scale from 0 with spring, centered at x,y */
export const Pop: React.FC<{f: number; at: number; x: number; y: number; s?: number; rot?: number; children: React.ReactNode; float?: number}> = ({f, at, x, y, s = 1, rot = 0, children, float = 0}) => {
  const p = pop(f, at);
  const fl = float ? Math.sin((f - at) / 14) * float : 0;
  return (
    <g transform={`translate(${x},${y + fl}) rotate(${rot}) scale(${Math.max(0.001, p * s)})`} opacity={clamp01(p * 1.6)}>
      {children}
    </g>
  );
};

/* ───────── stage: full-screen svg + camera + vignette ───────── */
export const Stage: React.FC<{
  f: number; dur: number; children: React.ReactNode;
  z0?: number; z1?: number; fx?: number; fy?: number;
  shake?: [number, number, number]; tint?: string; vignette?: number; fadeIn?: number;
}> = ({f, dur, children, z0 = 1.02, z1 = 1.08, fx = W / 2, fy = H / 2, shake, tint, vignette = 0.45, fadeIn = 8}) => {
  const z = interpolate(f, [0, dur], [z0, z1], {extrapolateRight: 'clamp'});
  let dx = 0, dy = 0;
  if (shake && f >= shake[0] && f <= shake[1]) {
    dx = Math.sin(f * 2.3) * shake[2];
    dy = Math.cos(f * 3.1) * shake[2] * 0.7;
  }
  return (
    <AbsoluteFill style={{opacity: fade(f, 0, fadeIn), background: '#000'}}>
      <svg width={W} height={H} viewBox={`0 0 ${W} ${H}`} style={{display: 'block'}}>
        <defs>
          <radialGradient id="vig" cx="50%" cy="50%" r="75%">
            <stop offset="55%" stopColor="#000" stopOpacity="0" />
            <stop offset="100%" stopColor="#000" stopOpacity={vignette} />
          </radialGradient>
        </defs>
        <g transform={`translate(${dx},${dy}) translate(${fx},${fy}) scale(${z}) translate(${-fx},${-fy})`}>{children}</g>
        {tint && <rect width={W} height={H} fill={tint} opacity={0.18} />}
        <rect width={W} height={H} fill="url(#vig)" />
      </svg>
    </AbsoluteFill>
  );
};

/* ───────── outlined primitives ───────── */
export const Rect: React.FC<React.SVGProps<SVGRectElement>> = (p) => <rect stroke={OUT} strokeWidth={SW} {...p} />;
export const Path: React.FC<React.SVGProps<SVGPathElement>> = (p) => <path stroke={OUT} strokeWidth={SW} strokeLinejoin="round" strokeLinecap="round" {...p} />;
export const Ell: React.FC<React.SVGProps<SVGEllipseElement>> = (p) => <ellipse stroke={OUT} strokeWidth={SW} {...p} />;
export const Txt: React.FC<{x: number; y: number; size?: number; fill?: string; weight?: number; anchor?: 'start' | 'middle' | 'end'; children: React.ReactNode; rot?: number}> = ({x, y, size = 40, fill = OUT, weight = 700, anchor = 'middle', children, rot = 0}) => (
  <text x={x} y={y} fontFamily={FONT} fontSize={size} fontWeight={weight} fill={fill} textAnchor={anchor} transform={rot ? `rotate(${rot} ${x} ${y})` : undefined}>{children}</text>
);
const Cap: React.FC<{x1: number; y1: number; x2: number; y2: number; w: number; c: string}> = ({x1, y1, x2, y2, w, c}) => (
  <>
    <line x1={x1} y1={y1} x2={x2} y2={y2} stroke={OUT} strokeWidth={w + 2 * SW} strokeLinecap="round" />
    <line x1={x1} y1={y1} x2={x2} y2={y2} stroke={c} strokeWidth={w} strokeLinecap="round" />
  </>
);

/* ───────── characters ───────── */
export type Expr = 'neutral' | 'happy' | 'sad' | 'angry' | 'shock' | 'think' | 'smug' | 'worry';

export type Look = {
  skin: string; hair: 'short' | 'shaggy' | 'sparse' | 'none'; hairC: string;
  top: 'shirt' | 'tee' | 'stripes' | 'panjabi' | 'gown' | 'ganji';
  topC: string; topC2?: string;
  sleeve: 'long' | 'short' | 'none' | 'rolled';
  bottom: 'pants' | 'lungi' | 'gownskirt'; botC: string; botC2?: string;
  shoe: 'shoe' | 'sandal' | 'sneaker' | 'bare'; shoeC: string;
  beard?: string; stache?: boolean; glasses?: 'thick' | 'thin'; topi?: boolean; shawl?: string;
  pocketBook?: boolean; bag?: boolean; watch?: boolean; circles?: boolean; marker?: boolean; slim?: boolean;
};

export type PersonProps = {
  who: Look; x: number; y: number; s?: number; f: number; flip?: boolean;
  expr?: Expr; mouth?: 0 | 1 | 2; armL?: number; armR?: number; holdL?: React.ReactNode; holdR?: React.ReactNode;
  walk?: boolean; sit?: boolean; shake?: number; rot?: number; tilt?: number; gaze?: number;
  bust?: boolean; phase?: number; cry?: boolean; sweat?: boolean; uid?: string; closed?: boolean;
};

const BROW: Record<Expr, number[]> = {
  neutral: [0, 0, 0, 0], happy: [-4, -4, -4, -4], sad: [-9, 3, -9, 3], angry: [9, -3, 9, -3],
  shock: [-11, -11, -11, -11], think: [-9, -9, 0, 0], smug: [0, 0, -3, -8], worry: [-8, 2, -8, 2],
};

const Mouth: React.FC<{expr: Expr; m: 0 | 1 | 2}> = ({expr, m}) => {
  if (m > 0) {
    return <ellipse cx={0} cy={-272} rx={m === 1 ? 9 : 13} ry={m === 1 ? 6 : 13} fill="#7a2a2a" stroke={OUT} strokeWidth={3} />;
  }
  const st = {fill: 'none', stroke: OUT, strokeWidth: 4, strokeLinecap: 'round' as const};
  switch (expr) {
    case 'happy': return <path d="M-17,-279 Q0,-255 17,-279 Z" fill="#7a2a2a" stroke={OUT} strokeWidth={3} strokeLinejoin="round" />;
    case 'sad': case 'worry': return <path d="M-12,-266 Q0,-279 12,-266" {...st} />;
    case 'angry': return <path d="M-13,-268 Q0,-277 13,-268" {...st} />;
    case 'shock': return <ellipse cx={0} cy={-268} rx={8} ry={11} fill="#7a2a2a" stroke={OUT} strokeWidth={3} />;
    case 'smug': return <path d="M-12,-272 Q4,-264 15,-279" {...st} />;
    case 'think': return <path d="M-9,-271 L9,-273" {...st} />;
    default: return <path d="M-11,-273 Q0,-266 11,-273" {...st} />;
  }
};

const Head: React.FC<{p: PersonProps; blinking: boolean}> = ({p, blinking}) => {
  const w = p.who, ex = p.expr ?? 'neutral', br = BROW[ex], g = (p.gaze ?? 0) * 3.5;
  const shock = ex === 'shock';
  return (
    <g>
      {/* ears */}
      <ellipse cx={-46} cy={-298} rx={7} ry={11} fill={w.skin} stroke={OUT} strokeWidth={SW} />
      <ellipse cx={46} cy={-298} rx={7} ry={11} fill={w.skin} stroke={OUT} strokeWidth={SW} />
      <ellipse cx={0} cy={-300} rx={46} ry={50} fill={w.skin} stroke={OUT} strokeWidth={SW} />
      {/* hair */}
      {w.hair === 'short' && <path d="M-47,-305 C-50,-346 -22,-358 0,-358 C22,-358 50,-346 47,-305 C40,-322 26,-333 0,-335 C-26,-333 -40,-322 -47,-305 Z" fill={w.hairC} stroke={OUT} strokeWidth={SW} strokeLinejoin="round" />}
      {w.hair === 'shaggy' && <path d="M-50,-298 C-64,-330 -42,-364 -18,-352 C-12,-370 14,-370 20,-352 C44,-366 66,-330 50,-298 C40,-324 28,-335 0,-337 C-28,-335 -40,-324 -50,-298 Z" fill={w.hairC} stroke={OUT} strokeWidth={SW} strokeLinejoin="round" />}
      {w.hair === 'sparse' && <path d="M-47,-300 C-50,-336 -26,-346 -6,-344 C-30,-336 -38,-322 -40,-300 Z M47,-300 C50,-336 26,-346 6,-344 C30,-336 38,-322 40,-300 Z" fill={w.hairC} stroke={OUT} strokeWidth={SW} strokeLinejoin="round" />}
      {w.topi && (
        <g>
          <path d="M-45,-322 C-45,-376 45,-376 45,-322 L45,-314 Q0,-306 -45,-314 Z" fill="#fff" stroke={OUT} strokeWidth={SW} strokeLinejoin="round" />
          <path d="M-22,-362 L-24,-318 M0,-368 L0,-312 M22,-362 L24,-318" stroke="#cfd6dc" strokeWidth={3} fill="none" />
        </g>
      )}
      {/* beard / stache */}
      {w.beard && <path d="M-46,-296 C-48,-240 48,-240 46,-296 C38,-276 24,-262 0,-262 C-24,-262 -38,-276 -46,-296 Z" fill={w.beard} stroke={OUT} strokeWidth={SW} strokeLinejoin="round" />}
      {/* dark circles */}
      {w.circles && (<><path d="M-27,-286 Q-17,-280 -7,-286" stroke="#7b6a7e" strokeWidth={5} fill="none" strokeLinecap="round" opacity={0.7} /><path d="M7,-286 Q17,-280 27,-286" stroke="#7b6a7e" strokeWidth={5} fill="none" strokeLinecap="round" opacity={0.7} /></>)}
      {/* eyes */}
      {[-17, 17].map((ex1) => (
        <g key={ex1}>
          {blinking ? (
            <path d={`M${ex1 - 9},-298 Q${ex1},-293 ${ex1 + 9},-298`} stroke={OUT} strokeWidth={4} fill="none" strokeLinecap="round" />
          ) : (
            <>
              <circle cx={ex1} cy={-298} r={shock ? 12 : 10} fill="#fff" stroke={OUT} strokeWidth={2.5} />
              <circle cx={ex1 + g} cy={-298} r={shock ? 3.5 : 5} fill={OUT} />
            </>
          )}
        </g>
      ))}
      {/* brows */}
      <line x1={-30} y1={-322 + br[1]} x2={-7} y2={-322 + br[0]} stroke={w.hair === 'sparse' || w.beard === '#f2f2f2' ? '#8c8c8c' : OUT} strokeWidth={5.5} strokeLinecap="round" />
      <line x1={30} y1={-322 + br[3]} x2={7} y2={-322 + br[2]} stroke={w.hair === 'sparse' || w.beard === '#f2f2f2' ? '#8c8c8c' : OUT} strokeWidth={5.5} strokeLinecap="round" />
      {/* glasses */}
      {w.glasses && (
        <g fill="rgba(255,255,255,0.25)" stroke={w.glasses === 'thick' ? OUT : '#7d848c'} strokeWidth={w.glasses === 'thick' ? 5.5 : 3}>
          <circle cx={-17} cy={-298} r={16} /><circle cx={17} cy={-298} r={16} />
          <path d="M-1,-298 L1,-298" fill="none" />
          <path d="M-33,-298 L-46,-302 M33,-298 L46,-302" fill="none" />
        </g>
      )}
      {w.stache && <path d="M-17,-282 Q-8,-293 0,-285 Q8,-293 17,-282 Q8,-278 0,-281 Q-8,-278 -17,-282 Z" fill={OUT} />}
      <Mouth expr={ex} m={p.mouth ?? 0} />
      {p.cry && [-17, 17].map((cx, i) => {
        const k = ((p.f + i * 9) % 26) / 26;
        return <ellipse key={cx} cx={cx} cy={-284 + k * 34} rx={5} ry={8} fill="#6ec1ff" opacity={1 - k * 0.7} stroke="#2b78b5" strokeWidth={1.5} />;
      })}
      {p.sweat && <path d={`M40,${-338 + (p.f % 30) * 0.6} q-7,12 0,17 q7,-5 0,-17 z`} fill="#8fd3ff" stroke="#2b78b5" strokeWidth={1.5} />}
    </g>
  );
};

export const Person: React.FC<PersonProps> = (p) => {
  const {who: w, x, y, s = 1.5, f, flip, walk, sit, bust} = p;
  const ph = p.phase ?? 0;
  const blinkAt = (f + ph * 17) % 96;
  const blinking = !!p.closed || blinkAt > 90;
  const breath = walk ? -Math.abs(Math.sin(f * 0.28)) * 9 : Math.sin((f / FPS) * 2 * Math.PI * 0.42 + ph) * 3;
  const sh = p.shake ?? 0;
  const dx = sh ? Math.sin(f * 2.3) * sh : 0, dy = sh ? Math.cos(f * 2.9) * sh * 0.6 : 0;
  const sitDrop = sit ? 52 : 0;
  const a = (v: number, k: number) => v + Math.sin((f / FPS) * 2 * Math.PI * 0.4 + ph + k) * 2.2;
  const aL = walk ? -8 - Math.sin(f * 0.28) * 28 : a(p.armL ?? -8, 0);
  const aR = walk ? 8 + Math.sin(f * 0.28) * 28 : a(p.armR ?? 8, 2);
  const SX = 47, SY = -238 + sitDrop, L = 94, AW = 22;
  const hand = (ang: number, side: number) => ({x: side * SX + L * Math.sin((ang * Math.PI) / 180), y: SY + L * Math.cos((ang * Math.PI) / 180)});
  const hL = hand(aL, -1), hR = hand(aR, 1);
  const uid = p.uid ?? `p${Math.round(x)}-${Math.round(y)}`;
  const slv = w.sleeve === 'none' ? 0 : w.sleeve === 'short' ? 0.38 : w.sleeve === 'rolled' ? 0.5 : 0.86;
  const slvC = w.top === 'ganji' ? w.topC : w.topC;
  const lung = w.bottom !== 'pants';
  const swing = walk ? Math.sin(f * 0.28) : 0;
  const hipY = -128 + sitDrop;
  const footY = -10;
  const footL = {x: -22 + swing * 30, y: footY - Math.max(0, -swing) * 12};
  const footR = {x: 22 - swing * 30, y: footY - Math.max(0, swing) * 12};
  const torsoTop = -254 + sitDrop, torsoBot = (w.top === 'panjabi' ? -62 : -118) + sitDrop;
  const slim = w.slim ? 0.88 : 1;
  const Arm: React.FC<{side: number; ang: number; h: {x: number; y: number}}> = ({side, ang, h}) => {
    const sx = side * SX;
    const mx = sx + (h.x - sx) * slv, my = SY + (h.y - SY) * slv;
    return (
      <g>
        <Cap x1={sx} y1={SY} x2={h.x} y2={h.y} w={AW * slim} c={w.skin} />
        {slv > 0 && <line x1={sx} y1={SY} x2={mx} y2={my} stroke={slvC} strokeWidth={AW * slim + 3} strokeLinecap="round" />}
        {slv > 0 && <line x1={mx} y1={my} x2={mx} y2={my} stroke={OUT} strokeWidth={2} />}
        <circle cx={h.x} cy={h.y} r={13} fill={w.skin} stroke={OUT} strokeWidth={SW} />
        {w.watch && side === -1 && (
          <g transform={`translate(${h.x - (h.x - sx) * 0.22},${h.y - (h.y - SY) * 0.22}) rotate(${-ang})`}><rect x={-13} y={-5} width={26} height={10} rx={3} fill="#cfd8dc" stroke={OUT} strokeWidth={2.5} /><circle r={4} fill="#fff" stroke={OUT} strokeWidth={1.5} /></g>
        )}
      </g>
    );
  };

  return (
    <g transform={`translate(${x + dx},${y + dy}) scale(${flip ? -s : s},${s})`}>
      <g transform={`rotate(${(flip ? -1 : 1) * (p.rot ?? 0)} 0 -120)`}>
        <g transform={`translate(0,${breath})`}>
          {/* legs */}
          {!bust && (
            <g>
              {lung ? (
                <>
                  <Cap x1={-20} y1={hipY} x2={footL.x} y2={footL.y} w={24} c={w.skin} />
                  <Cap x1={20} y1={hipY} x2={footR.x} y2={footR.y} w={24} c={w.skin} />
                </>
              ) : (
                <>
                  <Cap x1={-20} y1={hipY} x2={footL.x} y2={footL.y} w={26} c={w.botC} />
                  <Cap x1={20} y1={hipY} x2={footR.x} y2={footR.y} w={26} c={w.botC} />
                </>
              )}
              {[footL, footR].map((ft, i) =>
                w.shoe === 'bare' ? null : (
                  <ellipse key={i} cx={ft.x + 7} cy={ft.y + 2} rx={w.shoe === 'sandal' ? 22 : 25} ry={w.shoe === 'sandal' ? 7 : 12} fill={w.shoeC} stroke={OUT} strokeWidth={SW} />
                ),
              )}
              {w.shoe === 'sneaker' && [footL, footR].map((ft, i) => <path key={i} d={`M${ft.x - 16},${ft.y + 9} L${ft.x + 30},${ft.y + 9}`} stroke="#c8c8c8" strokeWidth={4} />)}
            </g>
          )}
          {/* lungi / skirt */}
          {!bust && lung && (
            <path d={`M-44,${hipY - 12} L44,${hipY - 12} L52,-52 L-52,-52 Z`} fill={w.botC} stroke={OUT} strokeWidth={SW} strokeLinejoin="round" />
          )}
          {!bust && lung && w.botC2 && [-24, 0, 24].map((lx) => <line key={lx} x1={lx} y1={hipY - 8} x2={lx * 1.2} y2={-56} stroke={w.botC2} strokeWidth={3} />)}
          {/* worn bag strap (behind torso arm) */}
          {w.bag && <path d="M-40,-246 L44,-130" stroke="#111" strokeWidth={9} />}
          {/* neck + torso */}
          <rect x={-12} y={-268 + sitDrop} width={24} height={26} fill={w.skin} stroke={OUT} strokeWidth={SW} />
          <clipPath id={`${uid}-c`}><rect x={-44 * slim} y={torsoTop} width={88 * slim} height={torsoBot - torsoTop} rx={24} /></clipPath>
          <rect x={-44 * slim} y={torsoTop} width={88 * slim} height={torsoBot - torsoTop} rx={24} fill={w.topC} stroke={OUT} strokeWidth={SW} />
          {w.top === 'stripes' && (
            <g clipPath={`url(#${uid}-c)`}>
              {Array.from({length: 7}).map((_, i) => <rect key={i} x={-50} y={torsoTop + 10 + i * 20} width={100} height={9} fill={w.topC2} />)}
            </g>
          )}
          {w.top === 'shirt' && (
            <g>
              <path d="M-14,-256 L0,-232 L-24,-238 Z M14,-256 L0,-232 L24,-238 Z" transform={`translate(0,${sitDrop})`} fill="#fff" stroke={OUT} strokeWidth={2.5} strokeLinejoin="round" />
              <line x1={0} y1={-232 + sitDrop} x2={0} y2={-120 + sitDrop} stroke={OUT} strokeWidth={2} opacity={0.5} />
              {[-210, -180, -150].map((by) => <circle key={by} cx={0} cy={by + sitDrop} r={2.6} fill={OUT} opacity={0.6} />)}
              <rect x={12} y={-214 + sitDrop} width={26} height={26} rx={4} fill={w.topC} stroke={OUT} strokeWidth={2.5} />
              {w.pocketBook && <rect x={17} y={-226 + sitDrop} width={15} height={22} rx={2} fill="#e9475a" stroke={OUT} strokeWidth={2.5} />}
            </g>
          )}
          {w.top === 'panjabi' && (
            <g>
              <line x1={0} y1={-252 + sitDrop} x2={0} y2={-150 + sitDrop} stroke={OUT} strokeWidth={2.5} />
              {[-232, -206, -180].map((by) => <circle key={by} cx={0} cy={by + sitDrop} r={3} fill="#d7dde2" stroke={OUT} strokeWidth={1.5} />)}
              <rect x={12} y={-200 + sitDrop} width={24} height={22} rx={4} fill="none" stroke={OUT} strokeWidth={2} opacity={0.45} />
            </g>
          )}
          {w.top === 'gown' && (
            <g>
              <path d={`M-18,-254 L0,-222 L18,-254`} transform={`translate(0,${sitDrop})`} fill="#e6f3e6" stroke={OUT} strokeWidth={2.5} />
              {[-200, -170, -140].map((by) => [-24, 0, 24].map((bx) => <circle key={`${bx}${by}`} cx={bx} cy={by + sitDrop} r={3} fill="#bfe0c8" />))}
            </g>
          )}
          {w.top === 'ganji' && <path d={`M-22,-254 Q0,-226 22,-254`} transform={`translate(0,${sitDrop})`} fill={w.skin} stroke={OUT} strokeWidth={2.5} />}
          {w.shawl && <path d={`M-52,-246 Q0,-270 52,-246 L58,-190 Q0,-210 -58,-190 Z`} transform={`translate(0,${sitDrop})`} fill={w.shawl} stroke={OUT} strokeWidth={SW} strokeLinejoin="round" />}
          {/* arms */}
          <Arm side={-1} ang={aL} h={hL} />
          <Arm side={1} ang={aR} h={hR} />
          {p.holdL && <g transform={`translate(${hL.x},${hL.y})`}>{p.holdL}</g>}
          {p.holdR && <g transform={`translate(${hR.x},${hR.y})`}>{p.holdR}</g>}
          {/* worn bag */}
          {w.bag && (
            <g>
              <rect x={42} y={-176 + sitDrop} width={50} height={62} rx={9} fill="#2c2c2c" stroke={OUT} strokeWidth={SW} />
              <rect x={46} y={-176 + sitDrop} width={42} height={20} rx={7} fill="#3a3a3a" stroke={OUT} strokeWidth={2} />
            </g>
          )}
          {/* head */}
          <g transform={`rotate(${(p.tilt ?? 0) - (p.rot ?? 0) * (flip ? -1 : 1) * 0.92} 0 ${-255 + sitDrop}) translate(0,${sitDrop})`}>
            <Head p={p} blinking={blinking} />
          </g>
        </g>
      </g>
    </g>
  );
};

/* ───────── simple icons (centered at 0,0, ~100 units) ───────── */
export type IconKind = 'q' | 'bulb' | 'book' | 'phone' | 'watch' | 'shoe' | 'cup' | 'pen' | 'check' | 'cross' | 'warn' | 'moon' | 'sun' | 'heart' | 'clock' | 'scan' | 'bus' | 'bed' | 'notes' | 'bubble';
export const Icon: React.FC<{k: IconKind; s?: number}> = ({k, s = 1}) => {
  const body = (() => {
    switch (k) {
      case 'q': return <><circle r={46} fill="#ffd23f" stroke={OUT} strokeWidth={SW} /><Txt x={0} y={26} size={72} weight={700}>?</Txt></>;
      case 'bulb': return <><circle cy={-8} r={34} fill="#ffe066" stroke={OUT} strokeWidth={SW} /><rect x={-16} y={22} width={32} height={22} rx={5} fill="#b0b7bd" stroke={OUT} strokeWidth={SW} /><path d="M-8,-4 L0,12 L8,-4" fill="none" stroke={OUT} strokeWidth={3} /><path d="M-52,-8 L-64,-8 M52,-8 L64,-8 M-38,-44 L-46,-54 M38,-44 L46,-54 M0,-52 L0,-64" stroke="#f4a100" strokeWidth={5} strokeLinecap="round" /></>;
      case 'book': return <><path d="M-48,-34 L0,-26 L48,-34 L48,34 L0,42 L-48,34 Z" fill="#4c9be8" stroke={OUT} strokeWidth={SW} strokeLinejoin="round" /><path d="M0,-26 L0,42" stroke={OUT} strokeWidth={SW} /><path d="M-34,-14 L-12,-10 M-34,2 L-12,6 M12,-10 L34,-14 M12,6 L34,2" stroke="#fff" strokeWidth={4} strokeLinecap="round" /></>;
      case 'notes': return <><rect x={-34} y={-44} width={68} height={88} rx={7} fill="#e9475a" stroke={OUT} strokeWidth={SW} /><rect x={-26} y={-36} width={8} height={72} fill="#b92f40" /><path d="M-8,-18 L22,-18 M-8,0 L22,0 M-8,18 L14,18" stroke="#fff" strokeWidth={5} strokeLinecap="round" /></>;
      case 'phone': return <><rect x={-26} y={-46} width={52} height={92} rx={10} fill="#2d3748" stroke={OUT} strokeWidth={SW} /><rect x={-20} y={-36} width={40} height={64} rx={4} fill="#8ed1fc" /><circle cy={36} r={4} fill="#fff" /></>;
      case 'scan': return <><rect x={-26} y={-46} width={52} height={92} rx={10} fill="#2d3748" stroke={OUT} strokeWidth={SW} /><rect x={-20} y={-36} width={40} height={64} rx={4} fill="#fff" /><path d="M-14,-20 L14,-20 M-14,-6 L14,-6 M-14,8 L6,8" stroke="#9aa5b1" strokeWidth={4} /><rect x={-24} y={-6} width={48} height={5} fill="#2ecc71" opacity={0.8} /></>;
      case 'watch': return <><rect x={-14} y={-60} width={28} height={120} rx={8} fill="#8d99a6" stroke={OUT} strokeWidth={SW} /><circle r={34} fill="#e5ebf0" stroke={OUT} strokeWidth={SW} /><circle r={26} fill="#fff" stroke={OUT} strokeWidth={2} /><path d="M0,-18 L0,0 L14,8" stroke={OUT} strokeWidth={4} fill="none" strokeLinecap="round" /></>;
      case 'clock': return <><circle r={46} fill="#fff" stroke={OUT} strokeWidth={SW} /><path d="M0,-30 L0,0 L22,12" stroke={OUT} strokeWidth={5} fill="none" strokeLinecap="round" /></>;
      case 'shoe': return <><path d="M-52,22 L-52,-10 Q-20,-14 -8,-34 L10,-24 Q26,6 56,10 Q58,30 48,30 L-48,30 Z" fill="#fff" stroke={OUT} strokeWidth={SW} strokeLinejoin="round" /><path d="M-52,22 L52,22" stroke="#ccd" strokeWidth={6} /></>;
      case 'cup': return <><path d="M-34,-24 L34,-24 L28,32 Q0,42 -28,32 Z" fill="#fff" stroke={OUT} strokeWidth={SW} strokeLinejoin="round" /><path d="M-31,-8 L31,-8 L28,32 Q0,42 -28,32 Z" fill="#c68a4e" /><path d="M34,-12 Q58,-10 54,8 Q50,22 30,20" fill="none" stroke={OUT} strokeWidth={SW} /><path d="M-10,-40 Q-4,-52 -10,-62 M8,-40 Q14,-52 8,-62" stroke="#aaa" strokeWidth={4} fill="none" strokeLinecap="round" /></>;
      case 'pen': return <><path d="M-44,40 L-30,10 L26,-46 L44,-28 L-12,28 Z" fill="#3a86c8" stroke={OUT} strokeWidth={SW} strokeLinejoin="round" /><path d="M-44,40 L-30,10 L-12,28 Z" fill="#ffe0b8" stroke={OUT} strokeWidth={SW} strokeLinejoin="round" /></>;
      case 'check': return <><circle r={46} fill="#2ecc71" stroke={OUT} strokeWidth={SW} /><path d="M-22,2 L-6,18 L24,-14" stroke="#fff" strokeWidth={10} fill="none" strokeLinecap="round" strokeLinejoin="round" /></>;
      case 'cross': return <><circle r={46} fill="#e63946" stroke={OUT} strokeWidth={SW} /><path d="M-18,-18 L18,18 M18,-18 L-18,18" stroke="#fff" strokeWidth={10} strokeLinecap="round" /></>;
      case 'warn': return <><path d="M0,-50 L50,38 L-50,38 Z" fill="#ffd23f" stroke={OUT} strokeWidth={SW} strokeLinejoin="round" /><Txt x={0} y={30} size={60}>!</Txt></>;
      case 'moon': return <><path d="M20,-44 A46,46 0 1,0 40,24 A38,38 0 1,1 20,-44 Z" fill="#ffe9a8" stroke={OUT} strokeWidth={SW} /></>;
      case 'sun': return <><circle r={30} fill="#ffb703" stroke={OUT} strokeWidth={SW} />{Array.from({length: 8}).map((_, i) => <line key={i} x1={0} y1={-42} x2={0} y2={-56} stroke="#ffb703" strokeWidth={6} strokeLinecap="round" transform={`rotate(${i * 45})`} />)}</>;
      case 'heart': return <path d="M0,40 C-60,-4 -40,-48 -16,-40 C-6,-36 0,-26 0,-26 C0,-26 6,-36 16,-40 C40,-48 60,-4 0,40 Z" fill="#ef476f" stroke={OUT} strokeWidth={SW} strokeLinejoin="round" />;
      case 'bus': return <><rect x={-54} y={-34} width={108} height={60} rx={12} fill="#f4a261" stroke={OUT} strokeWidth={SW} /><rect x={-44} y={-24} width={30} height={22} fill="#cfefff" /><rect x={-8} y={-24} width={30} height={22} fill="#cfefff" /><rect x={28} y={-24} width={16} height={22} fill="#cfefff" /><circle cx={-30} cy={28} r={11} fill="#333" stroke={OUT} strokeWidth={2} /><circle cx={30} cy={28} r={11} fill="#333" stroke={OUT} strokeWidth={2} /></>;
      case 'bed': return <><rect x={-54} y={-4} width={108} height={22} rx={5} fill="#fff" stroke={OUT} strokeWidth={SW} /><rect x={-54} y={-34} width={12} height={62} fill="#9aa5b1" stroke={OUT} strokeWidth={SW} /><rect x={-38} y={-18} width={34} height={16} rx={7} fill="#e8eef2" stroke={OUT} strokeWidth={2.5} /></>;
      case 'bubble': return <><ellipse rx={46} ry={34} fill="#fff" stroke={OUT} strokeWidth={SW} /><circle cx={-16} r={5} fill={OUT} /><circle r={5} fill={OUT} /><circle cx={16} r={5} fill={OUT} /></>;
    }
  })();
  return <g transform={`scale(${s})`}>{body}</g>;
};

/** Thought cloud with tail pointing to (tx,ty). Children are drawn centered in the cloud. */
export const Thought: React.FC<{f: number; at: number; x: number; y: number; w?: number; h?: number; tx: number; ty: number; children: React.ReactNode}> = ({f, at, x, y, w = 300, h = 190, tx, ty, children}) => {
  const p = pop(f, at, 13);
  const bob = Math.sin(f / 16) * 5;
  const dots = [0.2, 0.45, 0.72].map((k, i) => ({cx: tx + (x - tx) * (1 - k * 0.55), cy: ty + (y + h / 2 - ty) * (1 - k * 0.55), r: 8 + i * 5}));
  return (
    <g opacity={clamp01(p * 1.5)} transform={`translate(0,${bob})`}>
      {dots.map((d, i) => <circle key={i} cx={d.cx} cy={d.cy} r={d.r * p} fill="#fff" stroke={OUT} strokeWidth={SW} />)}
      <g transform={`translate(${x},${y}) scale(${Math.max(0.001, p)})`}>
        <ellipse rx={w / 2} ry={h / 2} fill="#fff" stroke={OUT} strokeWidth={SW} />
        {[-0.34, 0, 0.34].map((k, i) => <circle key={i} cx={k * w} cy={-h / 2 + 8 + (i === 1 ? -6 : 4)} r={26} fill="#fff" />)}
        <ellipse rx={w / 2 - 3} ry={h / 2 - 3} fill="#fff" />
        {children}
      </g>
    </g>
  );
};

/** Bold stamp / keyword card: pops with slight rotation, lives inside the scene */
export const Stamp: React.FC<{f: number; at: number; x: number; y: number; text: string; sub?: string; color?: string; rot?: number; size?: number; bg?: string}> = ({f, at, x, y, text, sub, color = '#e63946', rot = -6, size = 64, bg = '#fff8e8'}) => {
  const p = pop(f, at, 9);
  const w = Math.max(360, text.length * size * 0.62 + 90);
  return (
    <g transform={`translate(${x},${y}) rotate(${rot}) scale(${Math.max(0.001, 2.2 - 1.2 * p)})`} opacity={clamp01(p * 2)}>
      <rect x={-w / 2} y={-size * 0.95} width={w} height={size * 1.9 + (sub ? size * 0.5 : 0)} rx={14} fill={bg} stroke={color} strokeWidth={7} />
      <rect x={-w / 2 + 10} y={-size * 0.95 + 10} width={w - 20} height={size * 1.9 + (sub ? size * 0.5 : 0) - 20} rx={8} fill="none" stroke={color} strokeWidth={2.5} />
      <Txt x={0} y={size * 0.28} size={size} fill={color}>{text}</Txt>
      {sub && <Txt x={0} y={size * 0.95} size={size * 0.46} fill={OUT} weight={600}>{sub}</Txt>}
    </g>
  );
};

/** Small colored name pill above a character */
export const NamePill: React.FC<{f: number; at: number; x: number; y: number; text: string; color: string}> = ({f, at, x, y, text, color}) => {
  const p = pop(f, at, 12);
  const w = text.length * 30 + 56;
  return (
    <g transform={`translate(${x},${y - (1 - p) * 20})`} opacity={clamp01(p * 2)}>
      <rect x={-w / 2} y={-26} width={w} height={52} rx={26} fill={color} stroke={OUT} strokeWidth={SW} />
      <Txt x={0} y={12} size={32} fill="#fff">{text}</Txt>
    </g>
  );
};
