import React from 'react';
import {FPS, OUT, SW} from './theme';
import {useT, Rect, Txt, Ell, pop, clamp01} from './kit';
import {mouth as mouthOf, Who} from './data';

export type SP = {t0: number; dur: number};

/** per-scene helper: local frame, absolute seconds, sec→frame, window test */
export const useScene = (t0: number) => {
  const {f, T} = useT(t0);
  const at = (s: number) => Math.round((s - t0) * FPS);
  const win = (a: number, b: number) => T >= a && T < b;
  const m = (who: Who) => mouthOf(who, T);
  return {f, T, at, win, m};
};

/* ───────── hand-held props (drawn around 0,0 = the hand) ───────── */
export const NotebookProp: React.FC<{c?: string; s?: number}> = ({c = '#e9475a', s = 1}) => (
  <g transform={`scale(${s}) rotate(-10)`}>
    <rect x={-22} y={-38} width={44} height={60} rx={4} fill={c} stroke={OUT} strokeWidth={SW} />
    <rect x={-16} y={-38} width={7} height={60} fill="rgba(0,0,0,0.2)" />
    <path d="M-2,-20 H14 M-2,-8 H14" stroke="#fff" strokeWidth={4} strokeLinecap="round" />
  </g>
);
export const StackProp: React.FC = () => (
  <g>
    {['#e9475a', '#4c9be8', '#f2b441', '#5fb37a'].map((c, i) => (
      <rect key={i} x={-34 + (i % 2) * 6} y={-12 - i * 17} width={68} height={16} rx={3} fill={c} stroke={OUT} strokeWidth={SW} />
    ))}
  </g>
);
export const PhoneProp: React.FC<{s?: number}> = ({s = 1}) => (
  <g transform={`scale(${s})`}>
    <rect x={-15} y={-30} width={30} height={52} rx={7} fill="#2d3748" stroke={OUT} strokeWidth={SW} />
    <rect x={-11} y={-24} width={22} height={36} rx={3} fill="#8ed1fc" />
  </g>
);
export const MarkerProp: React.FC = () => (
  <g transform="rotate(25)">
    <rect x={-6} y={-30} width={12} height={44} rx={4} fill="#e63946" stroke={OUT} strokeWidth={SW} />
    <rect x={-6} y={-30} width={12} height={12} rx={3} fill="#fff" stroke={OUT} strokeWidth={2} />
  </g>
);
export const PenProp: React.FC = () => (
  <g transform="rotate(30)">
    <rect x={-4} y={-34} width={8} height={50} rx={3} fill="#3a86c8" stroke={OUT} strokeWidth={SW} />
    <path d="M-4,16 L0,26 L4,16 Z" fill="#222" />
  </g>
);

/* ───────── small scene pieces ───────── */
export const FlashCut: React.FC<{f: number; at: number}> = ({f, at}) => {
  const k = clamp01(1 - Math.abs(f - at) / 5);
  return k > 0 ? <rect x={-120} y={-60} width={2160} height={1200} fill="#fff" opacity={k * 0.9} /> : null;
};

/** Open notebook page — handwriting lines, optional bus ticket + tea ring */
export const NotePage: React.FC<{f: number; at: number; x: number; y: number; s?: number; ticket?: boolean; tea?: boolean; date?: string}> = ({f, at, x, y, s = 1, ticket, tea, date}) => {
  const p = pop(f, at, 10);
  return (
    <g transform={`translate(${x},${y}) rotate(-5) scale(${Math.max(0.001, p * s)})`} opacity={clamp01(p * 2)}>
      <rect x={-190} y={-250} width={380} height={500} rx={12} fill="#fffdf3" stroke={OUT} strokeWidth={5} />
      {[-190, -140, -90, -40, 10, 60, 110].map((ly, i) => (
        <line key={i} x1={-160} y1={ly} x2={160} y2={ly} stroke="#b9d3ee" strokeWidth={3} />
      ))}
      <path d="M-150,-200 q20,-20 40,0 t40,0 t40,0 M-150,-150 h200 M-150,-100 q60,-30 120,0 t120,0" stroke="#2a4a7f" strokeWidth={5} fill="none" strokeLinecap="round" />
      <circle cx={-90} cy={20} r={38} fill="none" stroke="#2a4a7f" strokeWidth={5} /><path d="M-90,20 L-40,-20 M-90,20 L-120,60" stroke="#2a4a7f" strokeWidth={5} strokeLinecap="round" />
      {date && <Txt x={-150} y={-218} size={34} fill="#2a4a7f" anchor="start">{date}</Txt>}
      {ticket && (
        <g transform="translate(70,140) rotate(8)">
          <rect x={-70} y={-34} width={140} height={68} rx={6} fill="#ffe08a" stroke={OUT} strokeWidth={3} />
          <path d="M-20,-34 V34" stroke={OUT} strokeWidth={2} strokeDasharray="6 6" />
          <Txt x={26} y={10} size={32}>১৫৳</Txt>
        </g>
      )}
      {tea && <g transform="translate(60,-60)"><Ell rx={56} ry={50} fill="none" stroke="#b5733a" strokeWidth={9} opacity={0.75} /><Ell rx={48} ry={42} fill="#c68a4e" opacity={0.25} stroke="none" /></g>}
    </g>
  );
};

/** Big "tea stain + hand-drawn diagram" book spread for the discovery moment */
export const BookSpread: React.FC<{f: number; at: number; x: number; y: number; flipAt: number}> = ({f, at, x, y, flipAt}) => {
  const p = pop(f, at, 10);
  const flip = clamp01((f - flipAt) / 12);
  return (
    <g transform={`translate(${x},${y}) rotate(-3) scale(${Math.max(0.001, p)})`} opacity={clamp01(p * 2)}>
      {/* cover */}
      <rect x={-300} y={-220} width={300} height={440} rx={10} fill="#1f5fa8" stroke={OUT} strokeWidth={5} />
      <rect x={0} y={-220} width={300} height={440} rx={10} fill="#fffdf3" stroke={OUT} strokeWidth={5} />
      {/* left page: printed diagram (copy of Sagar's drawing) */}
      <rect x={-290} y={-210} width={280} height={420} fill="#fffdf3" />
      <circle cx={-150} cy={-80} r={62} fill="none" stroke="#2a4a7f" strokeWidth={5} />
      <path d="M-150,-80 L-150,-142 M-150,-80 L-96,-48 M-150,-80 L-204,-48" stroke="#2a4a7f" strokeWidth={5} />
      <path d="M-250,90 L-60,90 M-250,90 L-250,0 M-250,70 q40,-80 90,-20 t100,-60" stroke="#2a4a7f" strokeWidth={5} fill="none" strokeLinecap="round" />
      <path d="M-250,150 h170 M-250,180 h120" stroke="#2a4a7f" strokeWidth={4} strokeLinecap="round" />
      {/* right page: even the tea stain was printed */}
      {[-150, -100, -50, 0, 50, 100, 150].map((ly, i) => <line key={i} x1={30} y1={ly} x2={270} y2={ly} stroke="#b9d3ee" strokeWidth={3} />)}
      <g transform="translate(190,60)"><Ell rx={64} ry={58} fill="none" stroke="#b5733a" strokeWidth={10} opacity={0.8} /><Ell rx={54} ry={48} fill="#c68a4e" opacity={0.25} stroke="none" /></g>
      <path d="M50,-180 q30,-24 60,0 t60,0 M50,-130 h180" stroke="#2a4a7f" strokeWidth={5} fill="none" strokeLinecap="round" />
      {/* cover that flips open */}
      <g transform={`translate(0,0) scale(${1 - flip * 2},1)`} opacity={flip < 1 ? 1 : 0}>
        <rect x={0} y={-220} width={300} height={440} rx={10} fill="#1f5fa8" stroke={OUT} strokeWidth={5} />
        <rect x={30} y={-170} width={240} height={130} rx={10} fill="#ffd23f" stroke={OUT} strokeWidth={4} />
        <Txt x={150} y={-95} size={62} fill={OUT}>সাজেশন</Txt>
        <Txt x={150} y={-48} size={44} fill={OUT}>বুক</Txt>
        <Txt x={150} y={120} size={34} fill="#fff" weight={600}>কোচিং সেন্টার</Txt>
      </g>
    </g>
  );
};

/** Simple table (front view) used for tuition / result scenes */
export const Table: React.FC<{x: number; y: number; w: number}> = ({x, y, w}) => (
  <g>
    <Rect x={x - w / 2} y={y} width={w} height={40} rx={7} fill="#a8733a" />
    <Rect x={x - w / 2 + 26} y={y + 40} width={22} height={180} fill="#7a4d22" />
    <Rect x={x + w / 2 - 48} y={y + 40} width={22} height={180} fill="#7a4d22" />
  </g>
);
