import {loadFont} from '@remotion/google-fonts/HindSiliguri';

export const {fontFamily: FONT} = loadFont('normal', {weights: ['400', '600', '700'], subsets: ['bengali', 'latin']});
export const W = 1920;
export const H = 1080;
export const FPS = 30;
export const AUDIO_SEC = 202.92;
export const TOTAL = Math.round((AUDIO_SEC + 3.2) * FPS); // narration + 3.2s closing question card
export const OUT = '#222222';
export const SW = 3;
export const C = {
  yellow: '#ffd23f', red: '#e63946', green: '#2a9d5c', blue: '#3a86c8', cream: '#fff4dc', ink: '#222222',
};
