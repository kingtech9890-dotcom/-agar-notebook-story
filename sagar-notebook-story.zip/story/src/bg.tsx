import React from 'react';
import {W, H, OUT, SW} from './theme';
import {Rect, Path, Ell, Txt} from './kit';

const rnd = (i: number) => {
  const x = Math.sin(i * 127.1 + 311.7) * 43758.5453;
  return x - Math.floor(x);
};

/** Edge-to-edge helper: a rect covering the whole screen (plus bleed for camera zoom) */
export const Fill: React.FC<{c: string; y?: number; h?: number; o?: number}> = ({c, y = -60, h = H + 120, o = 1}) => (
  <rect x={-120} y={y} width={W + 240} height={h} fill={c} opacity={o} />
);

/* ───────── village exterior pieces ───────── */
export const Palm: React.FC<{x: number; y: number; h?: number; f: number; k?: number}> = ({x, y, h = 420, f, k = 0}) => {
  const sw = Math.sin(f / 30 + k) * 3;
  const top = {x: x + 34, y: y - h};
  return (
    <g>
      <path d={`M${x - 10},${y} Q${x + 8},${y - h / 2} ${top.x},${top.y} L${top.x + 14},${top.y} Q${x + 22},${y - h / 2} ${x + 14},${y} Z`} fill="#8b6b45" stroke={OUT} strokeWidth={SW} />
      <g transform={`translate(${top.x + 7},${top.y}) rotate(${sw})`}>
        {[-150, -110, -70, -30, 10, 50, 90].map((a, i) => (
          <path key={i} d={`M0,0 Q${Math.cos((a * Math.PI) / 180) * 70},${Math.sin((a * Math.PI) / 180) * 70 - 40} ${Math.cos((a * Math.PI) / 180) * 150},${Math.sin((a * Math.PI) / 180) * 60 + 20} Q${Math.cos((a * Math.PI) / 180) * 70},${Math.sin((a * Math.PI) / 180) * 70 - 8} 0,0 Z`} fill={i % 2 ? '#3f8f4f' : '#4aa35a'} stroke={OUT} strokeWidth={SW} />
        ))}
        <circle cx={-6} cy={8} r={9} fill="#7a5a2a" stroke={OUT} strokeWidth={2} />
        <circle cx={10} cy={10} r={9} fill="#7a5a2a" stroke={OUT} strokeWidth={2} />
      </g>
    </g>
  );
};

/** Wooden hut with green tin roof, barred windows and a blue door */
export const Hut: React.FC<{x: number; y: number; w?: number; h?: number; door?: boolean}> = ({x, y, w = 760, h = 330, door = true}) => {
  const l = x - w / 2;
  return (
    <g>
      {/* roof */}
      <Path d={`M${l - 50},${y - h} L${l + 120},${y - h - 150} L${l + w - 120},${y - h - 150} L${l + w + 50},${y - h} Z`} fill="#4f8a55" />
      <Path d={`M${l + 120},${y - h - 150} L${l + w / 2},${y - h - 230} L${l + w - 120},${y - h - 150} Z`} fill="#c98b62" />
      <circle cx={l + w / 2} cy={y - h - 170} r={16} fill="#6b4a32" stroke={OUT} strokeWidth={SW} />
      {/* wall */}
      <Rect x={l} y={y - h} width={w} height={h} fill="#cf9168" />
      {Array.from({length: Math.floor(w / 46)}).map((_, i) => <line key={i} x1={l + 23 + i * 46} y1={y - h} x2={l + 23 + i * 46} y2={y} stroke="#a46f4b" strokeWidth={3} />)}
      {/* windows */}
      {[l + 70, l + w - 190].map((wx, i) => (
        <g key={i}>
          <Rect x={wx} y={y - h + 70} width={120} height={95} fill="#3d3028" />
          {[1, 2, 3].map((k) => <line key={k} x1={wx + k * 30} y1={y - h + 70} x2={wx + k * 30} y2={y - h + 165} stroke="#c9b29a" strokeWidth={5} />)}
        </g>
      ))}
      {door && (
        <g>
          <Rect x={x - 62} y={y - h + 40} width={124} height={h - 40} fill="#4c86c6" />
          <line x1={x} y1={y - h + 40} x2={x} y2={y} stroke={OUT} strokeWidth={SW} />
          <circle cx={x + 14} cy={y - 100} r={6} fill="#ffd23f" stroke={OUT} strokeWidth={2} />
        </g>
      )}
      {/* porch posts + base */}
      {[l + 8, l + w - 24].map((px) => <Rect key={px} x={px} y={y - h - 8} width={16} height={h + 8} fill="#8b6240" />)}
      <Rect x={l - 20} y={y - 14} width={w + 40} height={26} fill="#a9825c" />
    </g>
  );
};

export const Outdoor: React.FC<{f: number; mood?: 'day' | 'morning' | 'dusk'; ground?: number}> = ({f, mood = 'day', ground = 780}) => {
  const sky = mood === 'morning' ? ['#ffd9a0', '#fff2d0'] : mood === 'dusk' ? ['#e9967a', '#ffd9a8'] : ['#8cc9ea', '#f5ecc8'];
  return (
    <g>
      <defs>
        <linearGradient id={`sky-${mood}`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor={sky[0]} /><stop offset="1" stopColor={sky[1]} />
        </linearGradient>
      </defs>
      <rect x={-120} y={-60} width={W + 240} height={ground + 60} fill={`url(#sky-${mood})`} />
      <circle cx={1540} cy={190} r={mood === 'morning' ? 90 : 62} fill={mood === 'dusk' ? '#ff8c42' : '#ffe27a'} opacity={0.95} />
      {[[300, 150], [980, 230], [1380, 120]].map(([cx, cy], i) => (
        <g key={i} transform={`translate(${cx + ((f * 0.2 + i * 300) % 2300) - 300 - cx + cx},${cy})`} opacity={0.9}>
          <ellipse rx={90} ry={28} fill="#fff" /><ellipse cx={-50} cy={8} rx={60} ry={22} fill="#fff" /><ellipse cx={55} cy={10} rx={64} ry={22} fill="#fff" />
        </g>
      ))}
      <path d={`M-120,${ground - 40} Q300,${ground - 150} 700,${ground - 60} T1500,${ground - 70} T2100,${ground - 50} L2100,${ground} L-120,${ground} Z`} fill="#7fb77e" opacity={0.7} />
      {/* paddy field band + ground */}
      <rect x={-120} y={ground - 22} width={W + 240} height={70} fill="#9acd60" />
      {Array.from({length: 24}).map((_, i) => <path key={i} d={`M${-100 + i * 90},${ground + 40} L${-60 + i * 90},${ground - 18}`} stroke="#7cb342" strokeWidth={5} />)}
      <rect x={-120} y={ground + 40} width={W + 240} height={H - ground} fill="#d9b77e" />
      <path d={`M-120,${ground + 110} L${W + 120},${ground + 90} L${W + 120},${H + 60} L-120,${H + 60} Z`} fill="#cba670" />
    </g>
  );
};

/* ───────── interiors ───────── */
const Planks: React.FC<{y: number; c1: string; c2: string}> = ({y, c1, c2}) => (
  <g>
    <rect x={-120} y={y} width={W + 240} height={H - y + 60} fill={c1} />
    {Array.from({length: 7}).map((_, i) => <line key={i} x1={-120} y1={y + 30 + i * 52} x2={W + 120} y2={y + 30 + i * 52} stroke={c2} strokeWidth={3} />)}
    <rect x={-120} y={y - 14} width={W + 240} height={16} fill={c2} />
  </g>
);

export const LibraryBg: React.FC<{f: number}> = ({f}) => {
  const rows = [250, 400, 550, 700];
  return (
    <g>
      <Fill c="#ead7b1" h={780} y={-60} />
      <rect x={-120} y={560} width={W + 240} height={230} fill="#d9bf90" />
      <Planks y={770} c1="#b98655" c2="#9c6c40" />
      {/* signboard */}
      <Rect x={560} y={46} width={800} height={96} rx={14} fill="#2f7d4f" />
      <Txt x={960} y={118} size={64} fill="#fff">ইউনিয়ন পাঠাগার</Txt>
      {/* tall shelf */}
      <Rect x={70} y={170} width={820} height={610} fill="#8b5a2b" />
      {rows.map((ry, ri) => (
        <g key={ri}>
          <Rect x={90} y={ry - 120} width={780} height={126} fill="#6e4521" />
          {Array.from({length: 22}).map((_, i) => {
            const bh = 70 + rnd(ri * 40 + i) * 44, bw = 26 + rnd(i * 7 + ri) * 12;
            const cols = ['#d65a5a', '#4c9be8', '#f2b441', '#5fb37a', '#9b6fd6', '#e7e1d1'];
            const x0 = 100 + i * 35;
            if (ri === 1 && i >= 9 && i <= 15) return null; // the gap where the notebooks should be
            return <rect key={i} x={x0} y={ry - bh} width={bw} height={bh} fill={cols[Math.floor(rnd(i + ri * 9) * cols.length)]} stroke={OUT} strokeWidth={2} />;
          })}
          <rect x={90} y={ry + 2} width={780} height={12} fill="#a8733a" stroke={OUT} strokeWidth={2} />
        </g>
      ))}
      {/* window */}
      <Rect x={1230} y={190} width={320} height={300} fill="#bfe6ff" />
      <path d="M1230,350 L1550,350 M1390,190 L1390,490" stroke="#7a5a3a" strokeWidth={10} />
      <Rect x={1214} y={176} width={352} height={328} rx={6} fill="none" strokeWidth={10} />
      {/* fan */}
      <g transform="translate(1640,40)">
        <rect x={-6} y={-60} width={12} height={60} fill="#555" />
        <g transform={`rotate(${f * 22})`}>
          {[0, 120, 240].map((a) => <ellipse key={a} cx={0} cy={-80} rx={20} ry={78} fill="#d8d8d8" stroke={OUT} strokeWidth={SW} transform={`rotate(${a})`} opacity={0.9} />)}
        </g>
        <circle r={16} fill="#777" stroke={OUT} strokeWidth={SW} />
      </g>
    </g>
  );
};

export const LibraryCounter: React.FC = () => (
  <g>
    <Rect x={1010} y={770} width={760} height={330} fill="#8b5a2b" />
    <Rect x={990} y={750} width={800} height={36} rx={8} fill="#b07a42" />
    <Rect x={1040} y={800} width={700} height={250} fill="#7a4d22" />
    <rect x={1130} y={716} width={90} height={34} fill="#e9475a" stroke={OUT} strokeWidth={SW} />
    <rect x={1150} y={686} width={86} height={30} fill="#4c9be8" stroke={OUT} strokeWidth={SW} />
  </g>
);

export const MessBg: React.FC<{f: number; night?: boolean}> = ({f, night}) => (
  <g>
    <Fill c={night ? '#6a4a35' : '#d2a77c'} h={800} y={-60} />
    {Array.from({length: 24}).map((_, i) => <line key={i} x1={i * 84 - 20} y1={0} x2={i * 84 - 20} y2={800} stroke={night ? '#4e3626' : '#b58a60'} strokeWidth={3} />)}
    <Planks y={780} c1={night ? '#3f2c20' : '#a9794a'} c2={night ? '#2d1f16' : '#8a5f38'} />
    {/* window */}
    <Rect x={150} y={150} width={260} height={290} fill={night ? '#14213d' : '#bfe6ff'} />
    {night && <circle cx={320} cy={250} r={34} fill="#ffe9a8" />}
    <path d="M280,150 L280,440 M150,295 L410,295" stroke="#5a3d28" strokeWidth={9} />
    {/* wall calendar */}
    <Rect x={520} y={150} width={110} height={140} rx={6} fill="#fff8e8" />
    <rect x={520} y={150} width={110} height={36} fill="#e63946" stroke={OUT} strokeWidth={SW} />
    {/* hanging gamchha */}
    <line x1={1500} y1={130} x2={1800} y2={130} stroke="#4a3426" strokeWidth={5} />
    <Path d="M1560,130 L1660,130 L1650,330 L1570,330 Z" fill="#e76f51" />
    {/* chowki (wooden bed) */}
    <Rect x={1180} y={600} width={640} height={36} rx={6} fill="#c9a06a" />
    <Rect x={1200} y={636} width={22} height={190} fill="#7a5530" />
    <Rect x={1778} y={636} width={22} height={190} fill="#7a5530" />
    <Ell cx={1280} cy={590} rx={70} ry={26} fill="#f3efe6" />
    {/* lantern + table glow */}
    <Rect x={520} y={640} width={420} height={30} rx={6} fill="#8b5a2b" />
    <Rect x={560} y={670} width={20} height={170} fill="#6e4521" />
    <Rect x={880} y={670} width={20} height={170} fill="#6e4521" />
    <g transform="translate(720,590)">
      {night && <circle r={170 + Math.sin(f / 6) * 6} fill="#ffcf6a" opacity={0.22} />}
      <rect x={-18} y={-22} width={36} height={52} rx={8} fill="#cfefff" stroke={OUT} strokeWidth={SW} opacity={0.9} />
      <path d={`M0,-14 Q8,2 0,18 Q-8,2 0,-14 Z`} fill="#ffb703" />
      <rect x={-22} y={28} width={44} height={14} fill="#555" stroke={OUT} strokeWidth={SW} />
    </g>
  </g>
);

export const HospitalBg: React.FC = () => (
  <g>
    <Fill c="#d7ebd9" h={760} y={-60} />
    <rect x={-120} y={430} width={W + 240} height={340} fill="#b6d8be" />
    <line x1={-120} y1={430} x2={W + 120} y2={430} stroke="#8fbf9d" strokeWidth={6} />
    <rect x={-120} y={760} width={W + 240} height={H} fill="#e3e6e2" />
    <rect x={-120} y={752} width={W + 240} height={12} fill="#aab5ad" />
    <Rect x={1320} y={120} width={380} height={290} fill="#cfeaff" />
    {[0, 1, 2, 3, 4, 5].map((i) => <line key={i} x1={1320} y1={150 + i * 46} x2={1700} y2={150 + i * 46} stroke="#9bb9d0" strokeWidth={7} />)}
    <Rect x={140} y={150} width={430} height={78} rx={10} fill="#2f7d4f" />
    <Txt x={355} y={206} size={44} fill="#fff">উপজেলা স্বাস্থ্য কমপ্লেক্স</Txt>
  </g>
);

export const Bed: React.FC<{x: number; y: number}> = ({x, y}) => (
  <g>
    <Rect x={x - 380} y={y - 190} width={22} height={190} fill="#9aa5b1" />
    <Rect x={x + 358} y={y - 150} width={22} height={150} fill="#9aa5b1" />
    <Rect x={x - 380} y={y - 110} width={760} height={34} rx={6} fill="#c7d1d9" />
    <Rect x={x - 360} y={y - 150} width={720} height={50} rx={14} fill="#ffffff" />
    <Rect x={x - 350} y={y - 190} width={170} height={52} rx={22} fill="#eef3f6" />
    <rect x={x - 340} y={y - 76} width={12} height={76} fill="#7d8791" /><rect x={x + 330} y={y - 76} width={12} height={76} fill="#7d8791" />
  </g>
);

export const IVStand: React.FC<{x: number; y: number; f: number}> = ({x, y, f}) => (
  <g>
    <line x1={x} y1={y} x2={x} y2={y - 420} stroke="#8e99a4" strokeWidth={9} strokeLinecap="round" />
    <line x1={x - 70} y1={y} x2={x + 70} y2={y} stroke="#8e99a4" strokeWidth={9} strokeLinecap="round" />
    <Rect x={x - 28} y={y - 430} width={56} height={90} rx={14} fill="#d9f0ff" />
    <rect x={x - 22} y={y - 392} width={44} height={44} rx={10} fill="#8fd3ff" opacity={0.8} />
    <circle cx={x} cy={y - 330 + (f % 30) * 0.5} r={4} fill="#8fd3ff" />
  </g>
);

export const CoachingBg: React.FC = () => (
  <g>
    <Fill c="#f2e4bf" h={780} y={-60} />
    <Planks y={770} c1="#b89162" c2="#9a7647" />
    <Rect x={60} y={190} width={760} height={360} rx={8} fill="#2f5d50" />
    <Rect x={44} y={174} width={792} height={392} rx={10} fill="none" stroke="#8b5a2b" strokeWidth={14} />
    <path d="M120,300 L300,300 M120,360 L380,360 M120,420 L260,420 M480,290 q40,-60 80,0 t80,0" stroke="#e8f1ec" strokeWidth={6} fill="none" strokeLinecap="round" opacity={0.85} />
    <Rect x={520} y={50} width={880} height={92} rx={12} fill="#c0392b" />
    <Txt x={960} y={118} size={58} fill="#fff">রফিক স্যারের কোচিং সেন্টার</Txt>
    <Rect x={1380} y={200} width={300} height={280} fill="#cfeaff" />
    <path d="M1530,200 L1530,480 M1380,340 L1680,340" stroke="#7a5a3a" strokeWidth={9} />
  </g>
);

export const SirTable: React.FC = () => (
  <g>
    <Rect x={880} y={730} width={620} height={46} rx={8} fill="#a8733a" />
    <Rect x={920} y={776} width={26} height={170} fill="#7a4d22" /><Rect x={1430} y={776} width={26} height={170} fill="#7a4d22" />
    <Rect x={960} y={690} width={120} height={42} fill="#e9475a" /><Rect x={975} y={650} width={110} height={40} fill="#4c9be8" />
  </g>
);

/** dark vignette background for clean motion-graphic scenes */
export const GraphicBg: React.FC<{c?: string; c2?: string}> = ({c = '#34495e', c2 = '#1f2a36'}) => (
  <g>
    <defs>
      <radialGradient id="gbg" cx="50%" cy="45%" r="80%"><stop offset="0" stopColor={c} /><stop offset="1" stopColor={c2} /></radialGradient>
    </defs>
    <rect x={-120} y={-60} width={W + 240} height={H + 120} fill="url(#gbg)" />
  </g>
);

export const Bench: React.FC<{x: number; y: number; w?: number}> = ({x, y, w = 520}) => (
  <g>
    <Rect x={x - w / 2} y={y - 30} width={w} height={30} rx={6} fill="#8b6b45" />
    <Rect x={x - w / 2 + 20} y={y} width={20} height={90} fill="#6e5236" /><Rect x={x + w / 2 - 40} y={y} width={20} height={90} fill="#6e5236" />
  </g>
);
