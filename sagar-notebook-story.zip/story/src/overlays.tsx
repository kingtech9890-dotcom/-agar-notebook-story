import React from 'react';
import {AbsoluteFill, useCurrentFrame} from 'remotion';
import {FPS, FONT, W, H, OUT} from './theme';
import {BUBBLES, NOCAP, SCENES} from './data';
import {CAPS} from './captions';
import {fade, pop} from './kit';

const KEY = ['লাইব্রেরি', 'খাতা', 'নোট', 'বই', 'টিউশনি', 'পরীক্ষা', 'ঘড়ি', 'জুতা', 'সাজেশন', 'নাহিদ', 'সাগর', 'বাবা', 'প্রমাণ', 'পকেট', 'হাসপাতাল', 'কোচিং', 'চায়ের', 'ডায়াগ্রাম', 'বিশ্বাস', 'পরিশ্রম', 'স্মৃতি', 'আলমারি', 'ব্যানার', 'ফল'];
const inNoCap = (T: number) => NOCAP.some(([s, e]) => T >= s && T < e);

/** Floating bottom caption — only when no bubble / card is on screen */
export const Caption: React.FC = () => {
  const f = useCurrentFrame();
  const T = f / FPS;
  if (inNoCap(T)) return null;
  const c = CAPS.find(([s, e]) => T >= s && T < e);
  if (!c) return null;
  const lf = f - Math.round(c[0] * FPS);
  const p = Math.min(1, lf / 6);
  const words = c[2].split(' ');
  let hl = 0;
  return (
    <AbsoluteFill style={{justifyContent: 'flex-end', alignItems: 'center', pointerEvents: 'none'}}>
      <div style={{marginBottom: 62, padding: '10px 38px 16px', borderRadius: 22, background: 'rgba(20,14,10,0.58)', transform: `translateY(${(1 - p) * 22}px)`, opacity: p, fontFamily: FONT, fontSize: 56, fontWeight: 600, color: '#fff', whiteSpace: 'nowrap', textShadow: '0 3px 8px rgba(0,0,0,.6)'}}>
        {words.map((w, i) => {
          const key = hl < 2 && KEY.some((k) => w.includes(k));
          if (key) hl++;
          return <span key={i} style={key ? {color: '#ffd23f', fontWeight: 700} : undefined}>{w}{i < words.length - 1 ? ' ' : ''}</span>;
        })}
      </div>
    </AbsoluteFill>
  );
};

/** Speech callout bubbles — floating over the full-screen scene */
export const Bubbles: React.FC = () => {
  const f = useCurrentFrame();
  const T = f / FPS;
  return (
    <AbsoluteFill style={{pointerEvents: 'none'}}>
      {BUBBLES.filter((b) => T >= b.s && T < b.e).map((b, i) => {
        const lf = f - Math.round(b.s * FPS);
        const p = pop(lf, 0, 13);
        const left = Math.max(40, Math.min(W - 40 - b.w, b.x - b.w / 2));
        const tail = Math.max(50, Math.min(b.w - 50, b.x - left));
        return (
          <div key={i} style={{position: 'absolute', left, width: b.w, bottom: H - (b.y - 36), transform: `scale(${Math.max(0.01, p)})`, transformOrigin: `${tail}px 100%`, opacity: Math.min(1, p * 2)}}>
            <div style={{background: '#fff', border: `4px solid ${OUT}`, borderRadius: 30, padding: '16px 28px 22px', fontFamily: FONT, fontWeight: 700, fontSize: 48, lineHeight: 1.3, color: OUT, textAlign: 'center'}}>{b.text}</div>
            <svg width={70} height={44} style={{position: 'absolute', left: tail - 35, bottom: -40}} viewBox="0 0 70 44">
              <path d="M6,0 L35,42 L64,0 Z" fill="#fff" stroke={OUT} strokeWidth={4} strokeLinejoin="round" />
              <rect x={9} y={-3} width={52} height={7} fill="#fff" />
            </svg>
          </div>
        );
      })}
    </AbsoluteFill>
  );
};

/** Location / time pill — top-left floating badge */
export const SceneTag: React.FC = () => {
  const f = useCurrentFrame();
  const T = f / FPS;
  const sc = SCENES.find((s) => T >= s.s && T < s.e);
  if (!sc || !sc.tag || T < 3.4) return null;
  const lf = f - Math.round(sc.s * FPS);
  const p = pop(lf, 6, 14);
  const out = 1 - fade(lf, 90, 104);
  return (
    <AbsoluteFill style={{pointerEvents: 'none'}}>
      <div style={{position: 'absolute', left: 54, top: 46, padding: '8px 30px 12px', borderRadius: 40, background: '#e63946', border: `4px solid ${OUT}`, color: '#fff', fontFamily: FONT, fontWeight: 700, fontSize: 38, transform: `translateX(${(1 - p) * -80}px)`, opacity: Math.min(1, p * 2) * out}}>{sc.tag}</div>
    </AbsoluteFill>
  );
};

/** Viral hook: first 3 seconds, floats over scene 1 */
export const Hook: React.FC = () => {
  const f = useCurrentFrame();
  const T = f / FPS;
  if (T < 0.24 || T >= 3.4) return null;
  const lf = f - 7;
  const p = pop(lf, 0, 8);
  const out = 1 - fade(f, 90, 101);
  const shake = lf < 26 ? Math.sin(f * 2.6) * 9 : 0;
  const bookP = pop(lf, 20, 10);
  return (
    <AbsoluteFill style={{pointerEvents: 'none', opacity: out, background: `rgba(0,0,0,${0.5 * out})`}}>
      <div style={{position: 'absolute', top: 120, width: W, textAlign: 'center', transform: `translate(${shake}px,0) scale(${2 - p})`, opacity: Math.min(1, p * 2)}}>
        <span style={{display: 'inline-block', background: '#e63946', color: '#fff', border: `6px solid ${OUT}`, borderRadius: 18, padding: '6px 40px 14px', fontFamily: FONT, fontWeight: 700, fontSize: 112, transform: 'rotate(-3deg)'}}>৪ মাসের পরিশ্রম…</span>
      </div>
      <div style={{position: 'absolute', top: 330, width: W, textAlign: 'center', transform: `scale(${Math.max(0.01, pop(lf, 12, 9))})`}}>
        <span style={{display: 'inline-block', background: '#ffd23f', color: OUT, border: `6px solid ${OUT}`, borderRadius: 18, padding: '6px 40px 14px', fontFamily: FONT, fontWeight: 700, fontSize: 112, transform: 'rotate(2deg)'}}>বন্ধুই চুরি করল!</span>
      </div>
      <div style={{position: 'absolute', top: 620, left: W / 2 - 270, width: 540, transform: `scale(${Math.max(0.01, bookP)}) rotate(-4deg)`}}>
        <div style={{background: '#fff8e8', border: `6px solid ${OUT}`, borderRadius: 14, padding: '18px 24px', textAlign: 'center', fontFamily: FONT, color: OUT}}>
          <div style={{fontSize: 46, fontWeight: 700}}>সাজেশন বুক</div>
          <div style={{fontSize: 34, fontWeight: 600, marginTop: 6}}>নোট প্রস্তুতকারী: <span style={{color: '#e63946', textDecoration: 'line-through'}}>নাহিদ হাসান</span> ?</div>
        </div>
      </div>
    </AbsoluteFill>
  );
};
