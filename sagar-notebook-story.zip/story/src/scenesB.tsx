import React from 'react';
import {interpolate} from 'remotion';
import {W, H, OUT, SW} from './theme';
import {Stage, Person, Pop, Icon, Thought, Stamp, NamePill, Txt, Rect, Ell, Path, fade, clamp01} from './kit';
import {Fill, MessBg, Outdoor, Palm, Hut, HospitalBg, Bed, IVStand, CoachingBg, SirTable, GraphicBg, Bench} from './bg';
import {SAGAR, SAGAR_HOME, NAHID_OLD, NAHID_NEW, BABA, RAFIQ, PASSENGER} from './looks';
import {useScene, SP, NotebookProp, StackProp, PhoneProp, MarkerProp, FlashCut, NotePage, BookSpread} from './props';

/* ───── দৃশ্য ৩ক — নাহিদ বদলে যাচ্ছে ───── */
export const S3a: React.FC<SP> = ({t0, dur}) => {
  const {f, T, at, win} = useScene(t0);
  const nx = interpolate(f, [0, at(66)], [1050, 1480], {extrapolateRight: 'clamp'});
  const walking = T < 66;
  const look = T >= 67.6 ? NAHID_NEW : NAHID_OLD;
  return (
    <Stage f={f} dur={dur} z0={1.0} z1={1.07} fx={1100} fy={560}>
      <Outdoor f={f} mood="day" />
      <Palm x={140} y={800} h={460} f={f} />
      <Hut x={1050} y={800} />
      <Person who={SAGAR_HOME} x={520} y={960} s={1.5} f={f} expr="sad" armR={win(62.4, 65.4) ? 125 + Math.sin(f / 5) * 14 : 8} gaze={1} />
      <Person who={look} x={nx} y={960} s={1.5} f={f} phase={2} walk={walking} expr="smug" armR={walking ? undefined : 150} holdR={!walking ? <PhoneProp s={1.1} /> : undefined} gaze={-1} />
      {win(60.6, 65) && <Pop f={f} at={at(61.0)} x={1300} y={300} float={6}><Icon k="phone" s={1.3} /></Pop>}
      {win(67.6, 71.5) && <Pop f={f} at={at(67.6)} x={nx - 120} y={800} s={1.0} float={5}><Icon k="shoe" s={1.2} /></Pop>}
      {win(69.0, 71.5) && <Pop f={f} at={at(69.0)} x={nx + 160} y={560} s={1.0} float={5}><Icon k="watch" s={1.2} /></Pop>}
    </Stage>
  );
};

/* ───── দৃশ্য ৩খ — গ্রামের বাস, ব্যানার ───── */
export const S3b: React.FC<SP> = ({t0, dur}) => {
  const {f, T, at} = useScene(t0);
  const off = (f * 7) % 1200;
  const bx = interpolate(f, [at(76.2), at(77.6), at(78.9)], [1900, 1000, 760], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  return (
    <Stage f={f} dur={dur} z0={1.0} z1={1.06} fx={960} fy={420}>
      <Fill c="#2f5d62" />
      <clipPath id="busWin"><rect x={160} y={120} width={1600} height={560} rx={24} /></clipPath>
      <g clipPath="url(#busWin)">
        <rect x={160} y={120} width={1600} height={560} fill="#cfe9f5" />
        <rect x={160} y={480} width={1600} height={200} fill="#9acd60" />
        {[0, 1].map((k) => (
          <g key={k} transform={`translate(${-off + k * 1200},0)`}>
            {[160, 520, 900].map((px, i) => <Palm key={i} x={px} y={520} h={300 + (i % 2) * 60} f={f} k={i} />)}
            <g transform="translate(300,0) scale(0.45) translate(-400,0)"><Hut x={400} y={1090} w={560} h={280} door /></g>
          </g>
        ))}
        {/* roadside coaching banner on two poles */}
        <g transform={`translate(${bx},0)`}>
          <Rect x={-10} y={300} width={20} height={240} fill="#6e4521" /><Rect x={560} y={300} width={20} height={240} fill="#6e4521" />
          <Rect x={-30} y={190} width={640} height={190} rx={10} fill="#e63946" />
          <Txt x={290} y={265} size={78} fill="#fff">সাজেশন বুক</Txt>
          <Txt x={290} y={340} size={44} fill="#ffd23f">রফিক স্যারের কোচিং</Txt>
        </g>
      </g>
      <rect x={150} y={110} width={1620} height={580} rx={30} fill="none" stroke="#1e3c40" strokeWidth={22} />
      {/* seats */}
      <Rect x={60} y={760} width={760} height={360} rx={40} fill="#c0594d" />
      <Rect x={1100} y={760} width={760} height={360} rx={40} fill="#c0594d" />
      <Person who={SAGAR_HOME} x={600} y={880} s={1.4} f={f} sit expr="think" gaze={1} tilt={-5} />
      <Person who={PASSENGER} x={1350} y={880} s={1.4} f={f} phase={3} sit expr="neutral" />
      <Rect x={60} y={840} width={760} height={300} rx={36} fill="#a8463b" />
      <Rect x={1100} y={840} width={760} height={300} rx={36} fill="#a8463b" />
    </Stage>
  );
};

/* ───── দৃশ্য ৩গ — বই কেনা, পাতা উল্টানো, চমক ───── */
export const S3c: React.FC<SP> = ({t0, dur}) => {
  const {f, T, at, win} = useScene(t0);
  const shock = T >= 85.4;
  return (
    <Stage f={f} dur={dur} z0={1.0} z1={shock ? 1.12 : 1.06} fx={960} fy={500} shake={[at(85.4), at(86.5), 7]}>
      <MessBg f={f} />
      <Person who={SAGAR_HOME} x={560} y={960} s={1.5} f={f} expr={shock ? 'shock' : 'think'} shake={shock && T < 87 ? 3 : 0} gaze={1} armR={shock ? 100 : 60} />
      <BookSpread f={f} at={at(79.2)} x={1280} y={480} flipAt={at(81.2)} />
      {win(80, 85) && <Pop f={f} at={at(82)} x={1580} y={760} s={1} float={6}><Icon k="q" s={0.9} /></Pop>}
      {T >= 86.5 && T < 90.3 && <Pop f={f} at={at(86.5)} x={820} y={330} float={6}><Icon k="warn" s={1.4} /></Pop>}
      <Stamp f={f} at={at(90.4)} x={1000} y={900} text="নোট প্রস্তুতকারী: নাহিদ হাসান" color="#e63946" size={52} rot={-3} />
    </Stage>
  );
};

/* ───── দৃশ্য ৩ঘ — সেই রাতে মুখোমুখি ───── */
export const S3d: React.FC<SP> = ({t0, dur}) => {
  const {f, T, at, win, m} = useScene(t0);
  const nahid = T >= 96;
  return (
    <Stage f={f} dur={dur} z0={1.0} z1={1.09} fx={1100} fy={500} tint="#1d2a5a">
      <MessBg f={f} night />
      <Person who={SAGAR_HOME} x={700} y={960} s={1.5} f={f} expr={nahid ? 'sad' : 'angry'} shake={T < 96 ? 1.6 : 0} armR={80 + Math.sin(f / 6) * 6} holdR={<NotebookProp c="#1f5fa8" s={1.2} />} gaze={1} />
      <Person who={NAHID_NEW} x={1330} y={960} s={1.5} f={f} phase={2} expr="smug" mouth={m('nahid')} armL={nahid ? -60 + Math.sin(f / 5) * 16 : -8} armR={60} holdR={<PhoneProp />} gaze={-1} />
      {win(92.9, 96) && <NamePill f={f} at={at(93.0)} x={700} y={380} text="সত্যি বলো!" color="#e63946" />}
    </Stage>
  );
};

/* ───── দৃশ্য ৩ঙ — প্রমাণ সরিয়ে ফেলার ফ্লো ───── */
export const S3e: React.FC<SP> = ({t0, dur}) => {
  const {f, T, at, win} = useScene(t0);
  const Card: React.FC<{x: number; label: string; at: number; children: React.ReactNode; color?: string}> = ({x, label, at: a, children, color = '#fff8e8'}) => (
    <Pop f={f} at={a} x={x} y={470}>
      <Rect x={-190} y={-210} width={380} height={420} rx={22} fill={color} />
      <g transform="translate(0,-40)">{children}</g>
      <Txt x={0} y={160} size={52}>{label}</Txt>
    </Pop>
  );
  const arrow = (x1: number, x2: number, a: number, c = '#ffd23f') => (
    <g opacity={fade(f, a, a + 8)}>
      <path d={`M${x1},470 L${x2 - 30},470`} stroke={c} strokeWidth={14} strokeLinecap="round" strokeDasharray="22 16" strokeDashoffset={-f * 2} />
      <path d={`M${x2 - 50},430 L${x2},470 L${x2 - 50},510`} fill="none" stroke={c} strokeWidth={14} strokeLinecap="round" strokeLinejoin="round" />
    </g>
  );
  return (
    <Stage f={f} dur={dur} z0={1.0} z1={1.05} vignette={0.6}>
      <GraphicBg c="#3b2f4a" c2="#17111f" />
      <Card x={330} label="সাগরের খাতা" at={at(101.4)}><Icon k="notes" s={2.4} /></Card>
      {arrow(530, 740, at(102.6))}
      <Card x={960} label="পাঠাগার" at={at(103.0)}>
        <Icon k="book" s={2.2} />
        {T >= 104.2 && <g transform="translate(70,-50)"><Icon k="cross" s={1.3} /></g>}
      </Card>
      <g opacity={fade(f, at(104.4), at(104.4) + 8)}>
        <path d="M960,700 q0,120 -220,140" stroke="#e63946" strokeWidth={10} fill="none" strokeDasharray="20 14" strokeDashoffset={-f * 2} />
      </g>
      <Card x={1590} label="কোচিংয়ের আলমারি" at={at(105.0)} color="#e8f0ff">
        <rect x={-70} y={-100} width={140} height={190} rx={8} fill="#8b5a2b" stroke={OUT} strokeWidth={SW} />
        <line x1={0} y1={-100} x2={0} y2={90} stroke={OUT} strokeWidth={SW} />
        <circle cx={-14} cy={0} r={7} fill="#ffd23f" stroke={OUT} strokeWidth={2} /><circle cx={14} cy={0} r={7} fill="#ffd23f" stroke={OUT} strokeWidth={2} />
      </Card>
      {arrow(1100, 1380, at(105.4), '#e63946')}
      <Stamp f={f} at={at(106.4)} x={960} y={900} text="সরানো হয়েছিল — যাতে প্রমাণ না থাকে" color="#e63946" size={50} rot={-2} />
    </Stage>
  );
};

/* ───── দৃশ্য ৪ক — হাসপাতাল, বাবা ───── */
const HospitalRoom: React.FC<{f: number; T: number; sagarExpr: 'sad' | 'worry' | 'think'; babaOpen: boolean; babaMouth: 0 | 1 | 2; sagarArm?: number; hold?: React.ReactNode}> = ({f, T, sagarExpr, babaOpen, babaMouth, sagarArm = 8, hold}) => (
  <g>
    <HospitalBg />
    <Bed x={1180} y={880} />
    <Person who={BABA} x={1158} y={862} s={1.35} f={f} rot={-90} bust={false} expr={babaOpen ? 'sad' : 'neutral'} mouth={babaMouth} closed={!babaOpen} phase={4} />
    {/* grey blanket over his body */}
    <Rect x={1040} y={700} width={520} height={160} rx={22} fill="#9aa0a6" />
    <path d="M1040,740 L1560,740" stroke="#7d8389" strokeWidth={6} />
    <IVStand x={1650} y={880} f={f} />
    <Bench x={520} y={790} />
    <Person who={SAGAR} x={520} y={890} s={1.4} f={f} sit expr={sagarExpr} tilt={7} armR={sagarArm} holdR={hold} gaze={1} />
  </g>
);

export const S4a: React.FC<SP> = ({t0, dur}) => {
  const {f, T, m} = useScene(t0);
  return (
    <Stage f={f} dur={dur} z0={1.0} z1={1.07} fx={1000} fy={600} tint="#9be0b0">
      <HospitalRoom f={f} T={T} sagarExpr="sad" babaOpen={T >= 113.6} babaMouth={m('baba')} />
    </Stage>
  );
};

/* ───── দৃশ্য ৪খ — পকেট-খাতা ───── */
export const S4b: React.FC<SP> = ({t0, dur}) => {
  const {f, T, at, win} = useScene(t0);
  const nod = win(117, 119.2);
  return (
    <Stage f={f} dur={dur} z0={1.0} z1={1.08} fx={900} fy={560} tint="#9be0b0">
      <g>
        <HospitalRoom f={f} T={T} sagarExpr={T < 119.2 ? 'sad' : 'think'} babaOpen babaMouth={0} sagarArm={T >= 119.4 ? -10 : 8} />
      </g>
      {/* head nod overlay cue */}
      {nod && <Pop f={f} at={at(117.1)} x={720} y={420} s={0.8}><Icon k="cross" s={0.8} /></Pop>}
      <NotePage f={f} at={at(122.0)} x={1050} y={400} s={0.78} date="১২ ফাল্গুন" />
      <Pop f={f} at={at(123.2)} x={1330} y={210} float={7}><Icon k="bulb" s={1.6} /></Pop>
      {win(124.5, 128.7) && <Pop f={f} at={at(124.6)} x={780} y={250} float={5} s={0.9}><Icon k="pen" s={1.2} /></Pop>}
    </Stage>
  );
};

/* ───── দৃশ্য ৪গ — নাহিদ জানত না / পরদিন সকাল ───── */
export const S4c: React.FC<SP> = ({t0, dur}) => {
  const {f, T, at, win} = useScene(t0);
  const second = T >= 132.4;
  const wx = interpolate(f, [at(132.6), at(136.2)], [-120, 1150], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  return (
    <Stage f={f} dur={dur} z0={1.0} z1={1.06}>
      {!second ? (
        <g>
          <MessBg f={f} />
          <Person who={NAHID_NEW} x={960} y={960} s={1.5} f={f} phase={2} expr="smug" armR={60} holdR={<PhoneProp />} gaze={0} />
          <Thought f={f} at={at(129.4)} x={1330} y={290} w={340} h={210} tx={1010} ty={450}>
            <g transform="translate(-40,0)"><Icon k="notes" s={1.2} /></g>
            <g transform="translate(70,0)"><Icon k="q" s={1.0} /></g>
          </Thought>
        </g>
      ) : (
        <g>
          <Outdoor f={f} mood="morning" />
          <Palm x={160} y={800} h={470} f={f} />
          <g transform="translate(1500,0)"><Hut x={0} y={800} w={640} h={300} door={false} /></g>
          <Rect x={1290} y={420} width={420} height={90} rx={12} fill="#c0392b" />
          <Txt x={1500} y={485} size={46} fill="#fff">রফিক স্যারের কোচিং</Txt>
          <Person who={SAGAR} x={wx} y={960} s={1.5} f={f} walk expr="angry" />
          <FlashCut f={f} at={at(132.4)} />
        </g>
      )}
    </Stage>
  );
};

/* ───── দৃশ্য ৪ঘ — কোচিংয়ে স্যার রফিকের সামনে ───── */
export const S4d: React.FC<SP> = ({t0, dur}) => {
  const {f, T, at, win, m} = useScene(t0);
  const qs = [141.9, 143.3, 144.6];
  const nx = interpolate(f, [at(152.3), at(153.4)], [2150, 1600], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  const flip = win(145.8, 150.2);
  return (
    <Stage f={f} dur={dur} z0={1.0} z1={1.08} fx={1000} fy={560}>
      <CoachingBg />
      <Person who={RAFIQ} x={1180} y={900} s={1.45} f={f} phase={1} expr={T < 139.8 ? 'neutral' : T < 150 ? 'angry' : 'think'} armR={70} holdR={<MarkerProp />} gaze={-1} />
      <SirTable />
      <Person who={SAGAR} x={700} y={950} s={1.5} f={f} expr="think" mouth={m('sagar')} armL={win(136.3, 139.7) ? -70 + Math.sin(f / 4) * 14 : -8} armR={flip ? 70 + Math.sin(f / 4) * 10 : 8} holdR={flip ? <NotebookProp c="#e9475a" s={0.9} /> : undefined} gaze={1} />
      {qs.map((q, i) => T >= q && T < q + 2.2 && <Pop key={i} f={f} at={at(q)} x={1180 + (i - 1) * 110} y={380 - i * 8} s={0.9} float={4}><Icon k="q" s={1} /></Pop>)}
      {qs.map((q, i) => T >= q + 0.9 && T < q + 3.2 && <Pop key={i} f={f} at={at(q + 0.9)} x={700 + (i - 1) * 110} y={380} s={0.8} float={4}><Icon k="check" s={1} /></Pop>)}
      {T >= 147.6 && T < 151 && <Pop f={f} at={at(147.6)} x={940} y={330} s={1} float={5}><Icon k="notes" s={1.2} /></Pop>}
      <Person who={NAHID_NEW} x={nx} y={960} s={1.5} f={f} phase={2} expr="worry" sweat gaze={1} armL={-8} />
    </Stage>
  );
};
