import type {Look} from './kit';

const base = {sleeve: 'long' as const, shoe: 'shoe' as const, shoeC: '#3b2f2f'};

/** সাগর — ২১, রোগাটে, হালকা নীল ফুল-হাতা শার্ট, ধূসর প্যান্ট, কালো ব্যাগ */
export const SAGAR: Look = {...base, skin: '#c98f5e', hair: 'short', hairC: '#1d1d1d', top: 'shirt', topC: '#8ec5ee', bottom: 'pants', botC: '#8a8f98', circles: true, slim: true, pocketBook: true, bag: true};
export const SAGAR_NIGHT: Look = {...SAGAR, top: 'ganji', topC: '#f4f4f0', sleeve: 'none', bottom: 'lungi', botC: '#5a7fa8', botC2: '#2f4c75', shoe: 'bare', pocketBook: false, bag: false};
export const SAGAR_HOME: Look = {...SAGAR, bag: false, shoe: 'sandal', shoeC: '#5d4037'};
export const SAGAR_RESULT: Look = {...SAGAR, bag: false, sleeve: 'rolled', pocketBook: true};

/** নাহিদ — ২১, ঝাঁকড়া চুল, ডোরাকাটা টি-শার্ট, গাঢ় নীল জিন্স */
export const NAHID_OLD: Look = {...base, skin: '#d6a070', hair: 'shaggy', hairC: '#161616', top: 'stripes', topC: '#f5f5f5', topC2: '#222222', sleeve: 'short', bottom: 'pants', botC: '#1f3a6b', shoe: 'sandal', shoeC: '#6d4c41'};
export const NAHID_NEW: Look = {...NAHID_OLD, shoe: 'sneaker', shoeC: '#ffffff', watch: true};
export const NAHID_HOME: Look = {...NAHID_OLD, top: 'ganji', topC: '#e9e9e9', sleeve: 'none', bottom: 'lungi', botC: '#6a8f6a', botC2: '#3f6b3f', shoe: 'bare'};

/** বাবা — ৫২, রোগা ও ফ্যাকাশে, সবুজ রোগীর পোশাক, ধূসর চাদর */
export const BABA: Look = {...base, skin: '#d9b48c', hair: 'sparse', hairC: '#b8b8b8', top: 'gown', topC: '#b9dcc0', sleeve: 'short', bottom: 'gownskirt', botC: '#b9dcc0', shoe: 'bare', beard: '#a3a3a3', shawl: '#9aa0a6', slim: true};

/** চাচা আজিজ — ৫৮, সাদা পাঞ্জাবি, সাদা টুপি, মোটা কালো চশমা, সাদা দাড়ি */
export const AZIZ: Look = {...base, skin: '#c99a6b', hair: 'none', hairC: '#eee', top: 'panjabi', topC: '#fbfbf8', bottom: 'pants', botC: '#f1f1ec', shoe: 'sandal', shoeC: '#5d4037', topi: true, glasses: 'thick', beard: '#f2f2f2'};

/** স্যার রফিক — ৪০, ক্রিম ফরমাল শার্ট, কালো প্যান্ট, পাতলা চশমা, গোঁফ, হাতে লাল মার্কার */
export const RAFIQ: Look = {...base, skin: '#cf9867', hair: 'short', hairC: '#1b1b1b', top: 'shirt', topC: '#f3e3bd', bottom: 'pants', botC: '#252525', shoeC: '#1a1a1a', glasses: 'thin', stache: true, marker: true};

/** নামহীন এক্সট্রা */
export const KID: Look = {...base, skin: '#c28a5a', hair: 'short', hairC: '#161616', top: 'tee', topC: '#f4a261', sleeve: 'short', bottom: 'pants', botC: '#4a6fa5', shoe: 'bare', slim: true};
export const KID2: Look = {...KID, topC: '#e76f8a', botC: '#6a4c93'};
export const PASSENGER: Look = {...base, skin: '#bf8a5b', hair: 'short', hairC: '#202020', top: 'shirt', topC: '#c9a66b', bottom: 'pants', botC: '#4b4b4b', shoe: 'sandal', shoeC: '#5d4037'};
export const STUDENT: Look = {...base, skin: '#cf9d6c', hair: 'shaggy', hairC: '#1a1a1a', top: 'tee', topC: '#6fbf8e', sleeve: 'short', bottom: 'pants', botC: '#3d4a6b', shoe: 'sandal', shoeC: '#5d4037'};
