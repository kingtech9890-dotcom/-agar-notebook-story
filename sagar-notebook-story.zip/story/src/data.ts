import {RMS} from './rms';
import {FPS} from './theme';

export type Who = 'sagar' | 'nahid' | 'baba' | 'aziz' | 'rafiq';

/** Scene timeline (seconds) — taken from the SRT timing */
export const SCENES = [
  {id: 's1', s: 0, e: 19.3, tag: 'গ্রামের পাঠাগার'},
  {id: 's2a', s: 19.3, e: 23.4, tag: 'এক মাস আগে'},
  {id: 's2b', s: 23.4, e: 28.8, tag: 'টিনের মেসবাড়ি · রাত'},
  {id: 's2c', s: 28.8, e: 31.0, tag: 'টিউশনি · রাত'},
  {id: 's2d', s: 31.0, e: 34.5, tag: 'ভোরবেলা'},
  {id: 's2e', s: 34.5, e: 45.4, tag: 'মেসবাড়ি'},
  {id: 's2f', s: 45.4, e: 59.8, tag: 'মেসবাড়ি'},
  {id: 's3a', s: 59.8, e: 71.5, tag: 'কিছুদিন পর'},
  {id: 's3b', s: 71.5, e: 78.9, tag: 'গ্রামের বাস'},
  {id: 's3c', s: 78.9, e: 92.9, tag: 'সাজেশন বুক'},
  {id: 's3d', s: 92.9, e: 99.9, tag: 'সেই রাতে'},
  {id: 's3e', s: 99.9, e: 108.5, tag: 'সত্যিটা'},
  {id: 's4a', s: 108.5, e: 116.6, tag: 'উপজেলা স্বাস্থ্য কমপ্লেক্স'},
  {id: 's4b', s: 116.6, e: 128.7, tag: 'পরীক্ষার ১০ দিন আগে'},
  {id: 's4c', s: 128.7, e: 136.2, tag: 'পরদিন সকাল'},
  {id: 's4d', s: 136.2, e: 157.5, tag: 'কোচিং সেন্টার'},
  {id: 's5a', s: 157.5, e: 172.0, tag: 'এরপর'},
  {id: 's5b', s: 172.0, e: 184.7, tag: 'ফল বেরোনোর দিন'},
  {id: 's5c', s: 184.7, e: 189.2, tag: 'হাসপাতাল'},
  {id: 's5d', s: 189.2, e: 206.1, tag: ''},
] as const;

/** Where characters stand — shared by scenes and speech bubbles so tails point at the right head */
export const HEAD = (x: number, floor: number, s: number) => ({x, y: floor - 362 * s});

/** Speech bubbles: [start, end, speaker, text, target x, target y, width] */
export const BUBBLES: {s: number; e: number; who: Who; text: string; x: number; y: number; w: number}[] = [
  {s: 15.3, e: 19.3, who: 'aziz', text: 'এখানে তো কোনো খাতা জমা পড়েনি, বাবা। কেউ আনেওনি।', ...HEAD(1400, 905, 1.45), w: 640},
  {s: 49.0, e: 54.8, who: 'nahid', text: 'দোস্ত, আসল খাতাগুলো লাইব্রেরিতে রেখে আসি, বাড়ি নিলে নষ্ট হবে। আমি ফোনে স্ক্যান করে নিচ্ছি।', ...HEAD(1330, 950, 1.5), w: 760},
  {s: 96.0, e: 99.9, who: 'nahid', text: 'নোট তো কারো একার না, দোস্ত। তোর তো এমনিতেই সময় নেই।', ...HEAD(1330, 950, 1.5), w: 700},
  {s: 115.0, e: 116.6, who: 'baba', text: 'কাল রাতে কিছু খেয়েছিস?', x: 915, y: 640, w: 520},
  {s: 136.3, e: 139.7, who: 'sagar', text: 'স্যার, এই বইয়ের যেকোনো অধ্যায় থেকে আমাকে প্রশ্ন করুন।', ...HEAD(700, 950, 1.5), w: 700},
];

/** Intervals where a card/stamp/hook is on screen (captions are hidden) — scene files import these too */
export const CARDS: [number, number][] = [
  [0.24, 3.4],       // viral hook
  [19.3, 23.4],      // "এক মাস আগে" calendar card
  [39.8, 42.4],      // বড় পরীক্ষা stamp
  [90.3, 93.0],      // নোট প্রস্তুতকারী stamp
  [76.6, 78.9],      // roadside "সাজেশন বুক" banner
  [101.2, 108.3],    // প্রমাণ সরিয়ে ফেলা flow card
  [157.5, 160.4],
  [178.6, 181.2],    // Nahid's success post card
  [182.4, 184.7],    // result page card    // বিক্রি বন্ধ stamp
  [189.2, 206.1],    // moral cards + CTA
];
export const NOCAP: [number, number][] = [...BUBBLES.map((b) => [b.s, b.e] as [number, number]), ...CARDS];

/** Dialogue intervals — mouth moves only here, driven by the audio loudness */
export const SPEAK = BUBBLES.map((b) => ({s: b.s, e: b.e, who: b.who}));

export const mouth = (who: Who, T: number): 0 | 1 | 2 => {
  const on = SPEAK.some((x) => x.who === who && T >= x.s && T <= x.e);
  if (!on) return 0;
  const v = RMS[Math.min(RMS.length - 1, Math.floor(T * FPS))] ?? 0;
  return v < 2 ? 0 : v < 5 ? 1 : 2;
};
