import React from 'react';
import {interpolate} from 'remotion';
import {W, H, OUT, SW} from './theme';
import {Stage, Person, Pop, Icon, Thought, Stamp, NamePill, Txt, Rect, Ell, Path, fade, pop, clamp01} from './kit';
import {Fill, LibraryBg, LibraryCounter, MessBg, Outdoor, Palm, GraphicBg} from './bg';
import {SAGAR, SAGAR_NIGHT, SAGAR_HOME, NAHID_OLD, AZIZ, KID, KID2} from './looks';
import {useScene, SP, NotebookProp, StackProp, PhoneProp, PenProp, FlashCut, NotePage, Table} from './props';

/* ───── দৃশ্য ১ — গ্রামের পাঠাগার ───── */
export const S1: React.FC<SP> = ({t0, dur}) => {
  const {f, T, at, win, m} = useScene(t0);
  const searching = T < 11.2;
  const armL = searching ? -128 - Math.abs(Math.sin(f / 9)) * 26 : -18;
  const ex = T < 7.4 ? 'worry' : 'sad';
  const aziz = T >= 15.3;
  return (
    <Stage f={f} dur={dur} z0={1.0} z1={1.07} fx={800} fy={520}>
      <LibraryBg f={f} />
      <Person who={SAGAR} x={560} y={950} s={1.5} f={f} expr={ex} armL={armL} armR={12} gaze={-1} holdL={searching ? <NotebookProp c="#4c9be8" s={0.9} /> : undefined} tilt={searching ? -4 : 6} />
      {/* books piling up on the floor */}
      <Pop f={f} at={at(5.4)} x={300} y={965}><StackProp /></Pop>
      <Pop f={f} at={at(8.0)} x={820} y={985} s={0.8}><StackProp /></Pop>
      <Person who={AZIZ} x={1400} y={905} s={1.45} f={f} phase={2} expr={aziz ? 'neutral' : 'neutral'} mouth={m('aziz')} armR={T > 13.2 ? 70 : 20} holdR={T > 13.2 && T < 15.3 ? <Icon k="book" s={0.55} /> : undefined} gaze={T > 11.4 ? -1 : 0} />
      <LibraryCounter />
      {win(1.8, 5.6) && <NamePill f={f} at={at(1.8)} x={560} y={368} text="সাগর" color="#3a86c8" />}
      {win(11.5, 15.0) && <NamePill f={f} at={at(11.5)} x={1400} y={338} text="চাচা আজিজ" color="#2a9d5c" />}
      {win(3.6, 9.0) && <Thought f={f} at={at(3.6)} x={800} y={250} tx={600} ty={440}><Icon k="q" s={1.3} /></Thought>}
      {win(9.2, 13.0) && (
        <Thought f={f} at={at(9.2)} x={800} y={250} tx={600} ty={440}>
          <g transform="translate(-30,0)"><Icon k="notes" s={1.1} /></g>
          <g transform="translate(60,10)"><Icon k="cross" s={0.9} /></g>
        </Thought>
      )}
    </Stage>
  );
};

/* ───── দৃশ্য ২ক — "এক মাস আগে" ক্যালেন্ডার কার্ড ───── */
export const S2a: React.FC<SP> = ({t0, dur}) => {
  const {f, at} = useScene(t0);
  const page = Math.floor(fade(f, 8, 70) * 6);
  const flipK = (f * 0.5) % 1;
  return (
    <Stage f={f} dur={dur} z0={1.0} z1={1.05} tint="#8b5a2b" vignette={0.65}>
      <GraphicBg c="#6b4f2f" c2="#2b1d10" />
      <Pop f={f} at={3} x={960} y={420}>
        <Rect x={-230} y={-250} width={460} height={500} rx={18} fill="#fff8e8" />
        <rect x={-230} y={-250} width={460} height={110} rx={18} fill="#e63946" stroke={OUT} strokeWidth={SW} />
        {[-130, 130].map((rx) => <circle key={rx} cx={rx} cy={-250} r={14} fill="#999" stroke={OUT} strokeWidth={SW} />)}
        <Txt x={0} y={-168} size={64} fill="#fff">গত মাস</Txt>
        <Txt x={0} y={90} size={250} fill={OUT}>{['৩০', '২৫', '২০', '১৫', '১০', '০১', '০১'][page]}</Txt>
        <g transform={`translate(230,-250) rotate(${flipK * 40})`} opacity={1 - flipK}>
          <rect x={-460} width={460} height={500} fill="#fff8e8" stroke={OUT} strokeWidth={SW} />
        </g>
      </Pop>
      <g transform={`translate(1440,420) rotate(${-f * 6})`}><Icon k="clock" s={2.2} /></g>
      <path d="M1200,640 q-60,-40 -120,0" stroke="#ffd23f" strokeWidth={14} fill="none" strokeLinecap="round" />
      <Stamp f={f} at={at(19.9)} x={960} y={880} text="এক মাস আগে" color="#ffd23f" bg="#3a2a18" size={86} rot={-3} />
    </Stage>
  );
};

/* ───── দৃশ্য ২খ — মেসবাড়ি (রাত): দুই বন্ধু ───── */
export const S2b: React.FC<SP> = ({t0, dur}) => {
  const {f, at, win} = useScene(t0);
  const sad = win(26.8, 99);
  return (
    <Stage f={f} dur={dur} z0={1.0} z1={1.07} fx={1300} fy={520} tint="#1d2a5a">
      <MessBg f={f} night />
      <Person who={SAGAR_NIGHT} x={1050} y={960} s={1.5} f={f} expr={sad ? 'sad' : 'happy'} armL={win(23.8, 25) ? -70 + Math.sin(f / 4) * 14 : -10} gaze={1} tilt={sad ? 6 : 0} />
      <Person who={NAHID_OLD} x={1520} y={960} s={1.5} f={f} phase={3} expr="happy" armR={win(25.2, 26.4) ? 80 + Math.sin(f / 4) * 14 : 10} gaze={-1} />
      {win(23.9, 27) && <NamePill f={f} at={at(23.9)} x={1050} y={380} text="সাগর" color="#3a86c8" />}
      {win(25.2, 28.4) && <NamePill f={f} at={at(25.2)} x={1520} y={380} text="নাহিদ" color="#e07a1f" />}
      {win(26.9, 28.8) && (
        <Thought f={f} at={at(26.9)} x={800} y={300} w={320} h={200} tx={1000} ty={440}>
          <g transform="translate(-40,0)"><Icon k="bed" s={1.3} /></g>
          <g transform="translate(70,-6)"><Icon k="warn" s={0.8} /></g>
        </Thought>
      )}
    </Stage>
  );
};

/* ───── দৃশ্য ২গ — রাতের টিউশনি ───── */
export const S2c: React.FC<SP> = ({t0, dur}) => {
  const {f, at} = useScene(t0);
  return (
    <Stage f={f} dur={dur} z0={1.0} z1={1.06} tint="#1d2a5a">
      <MessBg f={f} night />
      <Rect x={720} y={700} width={560} height={30} rx={7} fill="#c9a06a" />
      <Rect x={760} y={730} width={22} height={120} fill="#7a5530" /><Rect x={1218} y={730} width={22} height={120} fill="#7a5530" />
      <Person who={KID} x={860} y={900} s={1.1} f={f} phase={1} sit expr="neutral" armR={30} holdR={<PenProp />} />
      <Person who={KID2} x={1140} y={900} s={1.1} f={f} phase={4} sit expr="think" />
      <Rect x={700} y={700} width={600} height={0.1} fill="none" stroke="none" />
      <Person who={SAGAR_HOME} x={380} y={960} s={1.5} f={f} expr="neutral" armR={85 + Math.sin(f / 7) * 12} holdR={<PenProp />} gaze={1} />
      <Pop f={f} at={at(29.0)} x={1580} y={230} float={8}><Icon k="moon" s={1.6} /></Pop>
      <Pop f={f} at={at(29.6)} x={1000} y={300} float={6} s={0.9}><Icon k="book" s={1} /></Pop>
    </Stage>
  );
};

/* ───── দৃশ্য ২ঘ — ভোর, চাপকল, স্নান, ক্লাসে ছোটা ───── */
export const S2d: React.FC<SP> = ({t0, dur}) => {
  const {f, T, at} = useScene(t0);
  const run = T >= 33.0;
  const rx = interpolate(f, [at(33.0), at(34.6)], [-150, 2050], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  return (
    <Stage f={f} dur={dur} z0={1.0} z1={1.05}>
      <Outdoor f={f} mood="morning" />
      <Palm x={200} y={800} h={470} f={f} />
      <Palm x={1760} y={800} h={400} f={f} k={2} />
      {/* tubewell (চাপকল) + bucket */}
      <g>
        <Rect x={1210} y={560} width={30} height={260} fill="#6b7a86" />
        <Path d="M1180,560 L1300,560 L1300,600 L1180,600 Z" fill="#7d8c99" />
        <Rect x={1290} y={600} width={16} height={60} fill="#6b7a86" />
        <Ell cx={1400} cy={820} rx={70} ry={20} fill="#3a86c8" />
        <Path d="M1330,780 L1470,780 L1450,860 L1350,860 Z" fill="#e0e0e0" />
        {!run && Array.from({length: 7}).map((_, i) => <circle key={i} cx={1298 + (i % 2) * 4} cy={670 + ((f * 6 + i * 22) % 130)} r={5} fill="#7cc4f2" />)}
      </g>
      {!run && (
        <Person who={SAGAR_NIGHT} x={1000} y={960} s={1.5} f={f} expr="neutral" armR={90 + Math.sin(f / 3) * 22} gaze={1} closed={Math.sin(f / 9) > 0.7} />
      )}
      {!run && <>{[0, 1, 2, 3, 4, 5].map((i) => <circle key={i} cx={930 + i * 28} cy={560 + ((f * 5 + i * 37) % 260)} r={4} fill="#7cc4f2" />)}</>}
      {run && <Person who={SAGAR} x={rx} y={960} s={1.5} f={f} walk expr="worry" />}
      <Pop f={f} at={at(31.2)} x={1560} y={200} float={6}><Icon k="sun" s={1.8} /></Pop>
      <FlashCut f={f} at={at(33.0)} />
    </Stage>
  );
};

/* ───── দৃশ্য ২ঙ — খাতার পাতা, চায়ের দাগ, নাহিদের আবদার ───── */
export const S2e: React.FC<SP> = ({t0, dur}) => {
  const {f, T, at, win} = useScene(t0);
  const talk = win(40.6, 45.4);
  return (
    <Stage f={f} dur={dur} z0={1.0} z1={1.07} fx={1000} fy={520}>
      <MessBg f={f} />
      <Person who={SAGAR_HOME} x={620} y={960} s={1.5} f={f} expr="sad" gaze={1} />
      <Person who={NAHID_OLD} x={1130} y={960} s={1.5} f={f} phase={2} expr={talk ? 'worry' : 'neutral'} armR={-5} armL={talk ? -60 + Math.sin(f / 5) * 18 : -8} holdR={<NotebookProp c="#e9475a" s={1} />} gaze={-1} />
      {win(34.8, 39.6) && <NotePage f={f} at={at(34.8)} x={1560} y={470} s={0.95} ticket tea />}
      {win(35.4, 39.6) && <Pop f={f} at={at(35.4)} x={1390} y={760} s={0.9} float={5}><Icon k="cup" /></Pop>}
      <Stamp f={f} at={at(39.9)} x={1130} y={330} text="সামনে বড় পরীক্ষা" color="#e63946" size={62} rot={-4} />
      {win(42.5, 45.4) && (
        <Thought f={f} at={at(42.5)} x={1550} y={290} w={330} h={200} tx={1170} ty={450}>
          <g transform="translate(-50,0)"><Icon k="notes" s={1.2} /></g>
          <g transform="translate(70,0)"><Icon k="q" s={0.9} /></g>
        </Thought>
      )}
    </Stage>
  );
};

/* ───── দৃশ্য ২চ — খাতা তুলে দেওয়া ───── */
export const S2f: React.FC<SP> = ({t0, dur}) => {
  const {f, T, at, win, m} = useScene(t0);
  const hand = T >= 58.0;
  const pack = T >= 55.4 && T < 58.0;
  return (
    <Stage f={f} dur={dur} z0={1.0} z1={1.07} fx={1000} fy={520}>
      <MessBg f={f} />
      <Person who={SAGAR_HOME} x={800} y={960} s={1.5} f={f} expr={T < 49 ? 'think' : T < 55 ? 'happy' : 'happy'} gaze={1}
        armR={pack ? 40 : hand ? 100 : 8} holdR={pack || hand ? <StackProp /> : undefined} />
      <Person who={NAHID_OLD} x={1330} y={960} s={1.5} f={f} phase={2} expr="happy" mouth={m('nahid')} armL={win(49, 54.8) ? -70 + Math.sin(f / 4) * 16 : -8} armR={win(49.4, 54.8) ? 60 : 8} holdR={win(49.4, 54.8) ? <PhoneProp /> : undefined} gaze={-1} />
      {win(49.6, 54.8) && <Pop f={f} at={at(53.0)} x={1000} y={380} s={0.9} float={6}><Icon k="scan" /></Pop>}
      {win(54.8, 59.8) && <NamePill f={f} at={at(54.9)} x={800} y={370} text="বিশ্বাস" color="#2a9d5c" />}
      {win(58.0, 59.8) && <Pop f={f} at={at(58.1)} x={1065} y={540} s={0.9} float={5}><Icon k="notes" s={1.1} /></Pop>}
    </Stage>
  );
};
