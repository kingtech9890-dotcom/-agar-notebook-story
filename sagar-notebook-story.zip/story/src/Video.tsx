import React from 'react';
import {AbsoluteFill, Audio, Sequence, staticFile} from 'remotion';
import {FPS, TOTAL} from './theme';
import {SCENES} from './data';
import {SCENE_COMPONENTS} from './scenes';
import {Bubbles, Caption, Hook, SceneTag} from './overlays';

export const Video: React.FC = () => (
  <AbsoluteFill style={{background: '#000'}}>
    {SCENES.map((sc) => {
      const Comp = SCENE_COMPONENTS[sc.id];
      const from = Math.round(sc.s * FPS);
      const end = sc.id === 's5d' ? TOTAL : Math.round(sc.e * FPS) + 8; // 8 frames overlap = cross-fade
      return (
        <Sequence key={sc.id} from={from} durationInFrames={end - from}>
          <Comp t0={sc.s} dur={end - from} />
        </Sequence>
      );
    })}
    {/* floating overlays — always on top of the 100% full-screen scene */}
    <Hook />
    <Bubbles />
    <SceneTag />
    <Caption />
    <Audio src={staticFile('voice.mp3')} volume={1} />
  </AbsoluteFill>
);
