import React from 'react';
import {interpolate} from 'remotion';
import {W, H, OUT, SW, FONT} from './theme';
import {Stage, Person, Pop, Icon, Thought, Stamp, Txt, Rect, Path, Ell, fade, pop, clamp01} from './kit';
import {Fill, MessBg, HospitalBg, Bed, IVStand, CoachingBg, GraphicBg, Bench} from './bg';
import {SAGAR, SAGAR_NIGHT, SAGAR_HOME, SAGAR_RESULT, BABA, KID, KID2} from './looks';
import {useScene, SP, NotebookProp, StackProp, PhoneProp, PenProp, FlashCut, Table} from './props';

/* ───── দৃশ্য ৫ক — বিক্রি বন্ধ, আলমারি থেকে খাতা, আবার পরিশ্রম ───── */
export const S5a: React.FC<SP> = ({t0, dur}) => {
  const {f, T, at, win} = useScene(t0);
  const phase = T < 160.4 ? 0 : T < 164.9 ? 1 : T < 166.9 ? 2 : T < 169.0 ? 3 : 4;
  const fly = (i: number) => clamp01((f - at(161.6 + i * 0.5)) / 22);
  return (
    <Stage f={f} dur={dur} z0={1.0} z1={1.06} tint={phase === 2 ? '#1d2a5a' : undefined}>
      {phase === 0 && (
        <g>
          <GraphicBg c="#3b2f4a" c2="#17111f" />
          <Pop f={f} at={at(157.6)} x={960} y={420} s={1.0}><Icon k="book" s={4} /></Pop>
          <Pop f={f} at={at(158.4)} x={1040} y={480} s={1.0}><Icon k="cross" s={3.4} /></Pop>
          <Stamp f={f} at={at(158.2)} x={960} y={860} text="বইয়ের বিক্রি বন্ধ" color="#e63946" size={84} rot={-4} />
        </g>
      )}
      {phase === 1 && (
        <g>
          <CoachingBg />
          {/* the cupboard (আলমারি) */}
          <Rect x={1100} y={280} width={300} height={520} rx={10} fill="#8b5a2b" />
          <Rect x={1118} y={298} width={130} height={484} fill="#2b1d10" />
          <g transform={`translate(1248,298) scale(${1 - fade(f, at(161.0), at(161.0) + 14) * 0.85},1)`}><Rect x={0} y={0} width={134} height={484} fill="#a8733a" /></g>
          {[0, 1, 2].map((i) => (
            <g key={i} transform={`translate(${interpolate(fly(i), [0, 1], [1180, 760])},${interpolate(fly(i), [0, 1], [480 + i * 60, 600], {})  - Math.sin(fly(i) * Math.PI) * 160})`} opacity={fly(i) > 0 ? 1 : 0}>
              <Icon k="notes" s={0.8} />
            </g>
          ))}
          <Person who={SAGAR} x={640} y={950} s={1.5} f={f} expr={T > 163 ? 'happy' : 'neutral'} armR={T > 162.4 ? 70 : 8} holdR={T > 163.4 ? <StackProp /> : undefined} gaze={1} />
        </g>
      )}
      {phase === 2 && (
        <g>
          <MessBg f={f} night />
          <Person who={SAGAR_HOME} x={900} y={960} s={1.5} f={f} expr="neutral" armR={70 + Math.sin(f / 6) * 10} holdR={<PenProp />} gaze={1} />
          <Pop f={f} at={at(165.1)} x={1500} y={230} float={8}><Icon k="moon" s={1.6} /></Pop>
          <Pop f={f} at={at(165.4)} x={1250} y={560} s={0.8} float={5}><Icon k="book" s={1.1} /></Pop>
          <Pop f={f} at={at(165.7)} x={520} y={600} s={0.9} float={5}><Icon k="cup" s={1} /></Pop>
        </g>
      )}
      {phase === 3 && (
        <g>
          <MessBg f={f} />
          <Person who={SAGAR_HOME} x={900} y={960} s={1.5} f={f} expr="neutral" armR={60} holdR={<NotebookProp c="#e9475a" s={1} />} gaze={0} tilt={4} />
          <Pop f={f} at={at(166.9)} x={1500} y={230} float={8}><Icon k="sun" s={1.7} /></Pop>
          <Pop f={f} at={at(167.4)} x={1150} y={360} float={6} s={0.9}><Icon k="bulb" s={1.3} /></Pop>
        </g>
      )}
      {phase === 4 && (
        <g>
          <CoachingBg />
          <Rect x={560} y={640} width={560} height={40} rx={7} fill="#a8733a" />
          <Rect x={590} y={680} width={20} height={200} fill="#7a4d22" /><Rect x={1070} y={680} width={20} height={200} fill="#7a4d22" />
          <Person who={SAGAR} x={840} y={900} s={1.45} f={f} sit expr="neutral" armR={50 + Math.sin(f / 5) * 8} holdR={<PenProp />} gaze={0} tilt={6} />
          <Rect x={640} y={640} width={160} height={4} fill="none" stroke="none" />
          <rect x={720} y={600} width={230} height={44} rx={3} fill="#fff" stroke={OUT} strokeWidth={SW} />
          <Pop f={f} at={at(169.2)} x={1450} y={300} float={6}><Icon k="clock" s={1.8} /></Pop>
        </g>
      )}
    </Stage>
  );
};

/* ───── দৃশ্য ৫খ — ফল বেরোনোর দিন ───── */
export const S5b: React.FC<SP> = ({t0, dur}) => {
  const {f, T, at, win} = useScene(t0);
  const swipe = fade(f, at(181.2), at(181.2) + 10);
  const postX = 1330 + swipe * 900;
  return (
    <Stage f={f} dur={dur} z0={1.0} z1={1.08} fx={900} fy={560}>
      <MessBg f={f} />
      <Person who={SAGAR_RESULT} x={730} y={900} s={1.5} f={f} sit expr={T < 178.4 ? 'neutral' : T < 182 ? 'think' : 'happy'} armR={55 + (T >= 181 && T < 182.3 ? Math.sin((f - at(181)) / 3) * 30 : 0)} holdR={<PenProp />} gaze={1} />
      {/* the empty table in front of him */}
      <Rect x={520} y={690} width={420} height={36} rx={7} fill="#a8733a" />
      <Rect x={545} y={726} width={22} height={180} fill="#7a4d22" /><Rect x={893} y={726} width={22} height={180} fill="#7a4d22" />
      {/* Nahid's success post card (floats in from the right, gets swiped away) */}
      {win(178.6, 182.4) && (
        <Pop f={f} at={at(178.6)} x={postX} y={400} s={1}>
          <Rect x={-250} y={-150} width={500} height={300} rx={22} fill="#fff" />
          <circle cx={-190} cy={-92} r={36} fill="#d6a070" stroke={OUT} strokeWidth={SW} />
          <Txt x={-130} y={-80} size={38} anchor="start">নাহিদ হাসান</Txt>
          <Txt x={0} y={30} size={60} fill="#2a9d5c">সাফল্যের গল্প!</Txt>
          <g transform="translate(-170,100)"><Icon k="heart" s={0.6} /></g>
          <Txt x={50} y={118} size={34} weight={600} fill="#555">১.২ হাজার লাইক</Txt>
        </Pop>
      )}
      {win(182.4, 184.7) && (
        <Pop f={f} at={at(182.4)} x={1330} y={400}>
          <Rect x={-250} y={-150} width={500} height={300} rx={22} fill="#fff" />
          <rect x={-250} y={-150} width={500} height={70} rx={22} fill="#3a86c8" stroke={OUT} strokeWidth={SW} />
          <Txt x={0} y={-100} size={46} fill="#fff">ফলাফল</Txt>
          <g transform="translate(0,35)"><Icon k="check" s={1.5} /></g>
        </Pop>
      )}
      <Pop f={f} at={at(173)} x={420} y={430} s={0.8} float={5}><Icon k="pen" s={1.2} /></Pop>
    </Stage>
  );
};

/* ───── দৃশ্য ৫গ — বাবার পাশে ───── */
export const S5c: React.FC<SP> = ({t0, dur}) => {
  const {f, T, at, m} = useScene(t0);
  return (
    <Stage f={f} dur={dur} z0={1.0} z1={1.07} fx={1000} fy={600} tint="#9be0b0">
      <HospitalBg />
      <Bed x={1180} y={880} />
      <Person who={BABA} x={1158} y={862} s={1.35} f={f} rot={-90} expr="happy" phase={4} />
      <Rect x={1040} y={700} width={520} height={160} rx={22} fill="#9aa0a6" />
      <path d="M1040,740 L1560,740" stroke="#7d8389" strokeWidth={6} />
      <IVStand x={1650} y={880} f={f} />
      <Bench x={520} y={790} />
      <Person who={SAGAR_RESULT} x={520} y={890} s={1.4} f={f} sit expr="happy" armR={60} holdR={<PhoneProp s={1.1} />} gaze={1} />
      <Pop f={f} at={at(186.4)} x={900} y={520} s={1.0} float={7}><Icon k="heart" s={1.4} /></Pop>
    </Stage>
  );
};

/* ───── দৃশ্য ৫ঘ — শিক্ষা কার্ড + দর্শকের প্রশ্ন ───── */
export const S5d: React.FC<SP> = ({t0, dur}) => {
  const {f, T, at, win} = useScene(t0);
  const Card: React.FC<{x: number; y: number; a: number; w?: number; h?: number; color?: string; children: React.ReactNode}> = ({x, y, a, w = 500, h = 300, color = '#fff8e8', children}) => (
    <Pop f={f} at={a} x={x} y={y}><Rect x={-w / 2} y={-h / 2} width={w} height={h} rx={24} fill={color} />{children}</Pop>
  );
  const phase = T < 198.4 ? 0 : T < 202.4 ? 1 : 2;
  return (
    <Stage f={f} dur={dur} z0={1.0} z1={1.05} vignette={0.6}>
      <GraphicBg c="#3a4a63" c2="#141b26" />
      {phase === 0 && (
        <g>
          <Card x={520} y={420} a={at(189.3)}>
            <g transform="translate(0,-40)"><Icon k="notes" s={1.7} /></g>
            <g transform="translate(90,-80)"><Icon k="warn" s={0.8} /></g>
            <Txt x={0} y={90} size={46}>খাতা হারিয়ে যেতে পারে</Txt>
          </Card>
          <Card x={1400} y={420} a={at(191.0)}>
            <g transform="translate(0,-40)"><Icon k="cross" s={1.7} /></g>
            <Txt x={0} y={90} size={46}>চুরিও হতে পারে</Txt>
          </Card>
          <Pop f={f} at={at(192.9)} x={960} y={850}>
            <Rect x={-760} y={-130} width={1520} height={260} rx={28} fill="#ffd23f" />
            <g transform="translate(-620,0)"><Icon k="pen" s={1.5} /></g>
            <g transform="translate(620,0)"><Icon k="bulb" s={1.4} /></g>
            <Txt x={0} y={-24} size={58}>নিজের হাতে লিখে, নিজের মাথায় জমানো</Txt>
            <Txt x={0} y={62} size={58} fill="#c0392b">কেউ সরাতে পারে না</Txt>
          </Pop>
        </g>
      )}
      {phase === 1 && (
        <g>
          {/* pocket metaphor */}
          <Pop f={f} at={at(198.5)} x={620} y={500}>
            <Rect x={-190} y={-210} width={380} height={440} rx={34} fill="#8ec5ee" />
            <rect x={-110} y={-30} width={220} height={190} rx={20} fill="#7bb4df" stroke={OUT} strokeWidth={SW} />
            <g transform={`translate(0,${interpolate(f, [at(199.0), at(200.6)], [-170, -70], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'})})`}><NotebookProp c="#e9475a" s={2.6} /></g>
            <rect x={-112} y={-30} width={224} height={120} rx={20} fill="#7bb4df" stroke={OUT} strokeWidth={SW} />
          </Pop>
          <Card x={1330} y={420} a={at(199.6)} w={760} h={360}>
            <Txt x={0} y={-30} size={56}>বিশ্বাস করলেও…</Txt>
            <Txt x={0} y={60} size={50} fill="#c0392b">নিজের পরিশ্রমের একটা অংশ</Txt>
            <Txt x={0} y={125} size={50} fill="#c0392b">নিজের পকেটে রেখো</Txt>
          </Card>
        </g>
      )}
      {phase === 2 && (
        <g>
          <Pop f={f} at={at(202.6)} x={960} y={300}>
            <Rect x={-820} y={-120} width={1640} height={240} rx={30} fill="#fff8e8" />
            <Txt x={0} y={-10} size={64}>আপনি কি কখনো কাউকে অন্ধভাবে</Txt>
            <Txt x={0} y={74} size={64}>বিশ্বাস করে ঠকেছেন?</Txt>
          </Pop>
          <Pop f={f} at={at(203.2)} x={620} y={690}>
            <Rect x={-260} y={-90} width={520} height={180} rx={90} fill="#e63946" />
            <Txt x={0} y={22} size={60} fill="#fff">হ্যাঁ, ঠকেছি</Txt>
          </Pop>
          <Pop f={f} at={at(203.5)} x={1300} y={690}>
            <Rect x={-260} y={-90} width={520} height={180} rx={90} fill="#2a9d5c" />
            <Txt x={0} y={22} size={60} fill="#fff">না, সতর্ক ছিলাম</Txt>
          </Pop>
          <Pop f={f} at={at(204.0)} x={960} y={930} s={1}>
            <Txt x={0} y={0} size={46} fill="#ffd23f">কমেন্টে আপনার অভিজ্ঞতা জানান</Txt>
          </Pop>
        </g>
      )}
    </Stage>
  );
};
